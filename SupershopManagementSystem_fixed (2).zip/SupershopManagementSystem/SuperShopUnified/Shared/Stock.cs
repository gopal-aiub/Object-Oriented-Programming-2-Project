using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class Stock : Form
    {
        private static readonly Color LowStockColor = Color.FromArgb(255, 224, 224);

        public Stock()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;
            lblstock.Text = "Stock";

            this.chkbox1.CheckedChanged += delegate { LoadStock(); };
            this.btnnotify1.Click += btnnotify1_Click;
            this.btnnotify2.Click += btnnotify2_Click;
            this.btnback.Click += delegate { this.Close(); };
            this.Load += delegate { LoadStock(); };
        }

        private void LoadStock()
        {
            try
            {
                string sql =
                    "SELECT ProductID, ProductCode AS Code, ProductName AS Product, Category, " +
                    "       Price, StockQty AS Stock, ReorderLevel AS [Low Limit], " +
                    "       CASE WHEN StockQty <= ReorderLevel THEN 'LOW STOCK' ELSE 'OK' END AS Situation " +
                    "FROM Products WHERE IsActive = 1 " +
                    (chkbox1.Checked ? "AND StockQty <= ReorderLevel " : "") +
                    "ORDER BY StockQty";

                DataTable table = DB.GetTable(sql);
                dataGridView1.DataSource = table;

                if (dataGridView1.Columns.Contains("ProductID"))
                    dataGridView1.Columns["ProductID"].Visible = false;
                if (dataGridView1.Columns.Contains("Price"))
                    dataGridView1.Columns["Price"].DefaultCellStyle.Format = "N2";

                int lowCount = 0;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["Situation"].Value != null &&
                        row.Cells["Situation"].Value.ToString() == "LOW STOCK")
                    {
                        row.DefaultCellStyle.BackColor = LowStockColor;
                        lowCount++;
                    }
                }

                lblstockshow.Text = table.Rows.Count + " products, " + lowCount + " low";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load stock: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SendNotification(int productId, string productName, int stock, int limit)
        {
            DB.Execute("INSERT INTO Notifications (ProductID, Message, CreatedBy) VALUES (@pid, @msg, @by)",
                DB.P("@pid", productId),
                DB.P("@msg", "LOW STOCK: " + productName + " has only " + stock +
                             " left (low limit " + limit + "). Reported by " + Session.FullName + "."),
                DB.P("@by", Session.UserId));
        }

        private void btnnotify1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a product first.", "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int productId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ProductID"].Value);
            string name = dataGridView1.CurrentRow.Cells["Product"].Value.ToString();
            int stock = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Stock"].Value);
            int limit = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Low Limit"].Value);

            if (stock > limit)
            {
                MessageBox.Show("This product is not in low stock.", "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                SendNotification(productId, name, stock, limit);
                MessageBox.Show("Manager notified about '" + name + "'.", "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnnotify2_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable low = DB.GetTable(
                    "SELECT ProductID, ProductName, StockQty, ReorderLevel " +
                    "FROM Products WHERE IsActive = 1 AND StockQty <= ReorderLevel");

                if (low.Rows.Count == 0)
                {
                    MessageBox.Show("No product is in low stock right now.", "Notify Manager",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (MessageBox.Show("Send " + low.Rows.Count + " low stock message(s) to the manager?",
                        "Notify Manager", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;

                foreach (DataRow row in low.Rows)
                {
                    SendNotification(
                        Convert.ToInt32(row["ProductID"]),
                        row["ProductName"].ToString(),
                        Convert.ToInt32(row["StockQty"]),
                        Convert.ToInt32(row["ReorderLevel"]));
                }

                MessageBox.Show("Manager notified.", "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Notify Manager",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
