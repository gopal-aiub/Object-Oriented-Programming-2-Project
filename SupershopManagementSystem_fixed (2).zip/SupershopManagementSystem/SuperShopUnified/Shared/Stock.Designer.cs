namespace SuperShopUnified
{
    partial class Stock
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnnotify1 = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnnotify2 = new System.Windows.Forms.Button();
            this.lblstock = new System.Windows.Forms.Label();
            this.lblstockshow = new System.Windows.Forms.Label();
            this.chkbox1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();

            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(113, 86);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(590, 225);
            this.dataGridView1.TabIndex = 0;

            this.btnnotify1.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnnotify1.FlatAppearance.BorderSize = 2;
            this.btnnotify1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnotify1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnotify1.Location = new System.Drawing.Point(30, 333);
            this.btnnotify1.Name = "btnnotify1";
            this.btnnotify1.Size = new System.Drawing.Size(264, 83);
            this.btnnotify1.TabIndex = 1;
            this.btnnotify1.Text = "Notify manager (selected)";
            this.btnnotify1.UseVisualStyleBackColor = false;

            this.btnback.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnback.FlatAppearance.BorderSize = 2;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(598, 333);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(110, 78);
            this.btnback.TabIndex = 2;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;

            this.btnnotify2.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnnotify2.FlatAppearance.BorderSize = 2;
            this.btnnotify2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnotify2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnotify2.Location = new System.Drawing.Point(362, 333);
            this.btnnotify2.Name = "btnnotify2";
            this.btnnotify2.Size = new System.Drawing.Size(167, 78);
            this.btnnotify2.TabIndex = 3;
            this.btnnotify2.Text = "Notify Manager (all)";
            this.btnnotify2.UseVisualStyleBackColor = false;

            this.lblstock.AutoSize = true;
            this.lblstock.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.lblstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstock.Location = new System.Drawing.Point(108, 51);
            this.lblstock.Name = "lblstock";
            this.lblstock.Size = new System.Drawing.Size(67, 25);
            this.lblstock.TabIndex = 4;
            this.lblstock.Text = "Stock";

            this.lblstockshow.AutoSize = true;
            this.lblstockshow.Location = new System.Drawing.Point(210, 51);
            this.lblstockshow.Name = "lblstockshow";
            this.lblstockshow.Size = new System.Drawing.Size(0, 16);
            this.lblstockshow.TabIndex = 5;

            this.chkbox1.AutoSize = true;
            this.chkbox1.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.chkbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbox1.Location = new System.Drawing.Point(529, 31);
            this.chkbox1.Name = "chkbox1";
            this.chkbox1.Size = new System.Drawing.Size(204, 20);
            this.chkbox1.TabIndex = 6;
            this.chkbox1.Text = "Show only  low stock item";
            this.chkbox1.UseVisualStyleBackColor = false;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.chkbox1);
            this.Controls.Add(this.lblstockshow);
            this.Controls.Add(this.lblstock);
            this.Controls.Add(this.btnnotify2);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnnotify1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Stock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stock";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnnotify1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnnotify2;
        private System.Windows.Forms.Label lblstock;
        private System.Windows.Forms.Label lblstockshow;
        private System.Windows.Forms.CheckBox chkbox1;
    }
}