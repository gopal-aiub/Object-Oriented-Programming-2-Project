using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public class NotificationsForm : Form
    {
        private DataGridView grid;
        private Label lblTitle;
        private Label lblCount;
        private Button btnMarkRead;
        private Button btnRefresh;
        private Button btnClose;

        public NotificationsForm()
        {
            BuildUi();
            this.Load += delegate { LoadNotifications(); };
        }

        private void BuildUi()
        {
            this.Text = "Notifications";
            this.Width = 820;
            this.Height = 480;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MinimizeBox = false;
            this.MaximizeBox = false;

            lblTitle = new Label
            {
                Text = "Notifications from Sales Executives",
                Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(16, 12)
            };

            grid = new DataGridView
            {
                Location = new Point(16, 50),
                Size = new Size(this.ClientSize.Width - 32, 320),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            lblCount = new Label { Location = new Point(16, 382), AutoSize = true, ForeColor = Color.Firebrick,
                Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold) };

            btnMarkRead = new Button { Text = "Mark as Read", Location = new Point(16, 410), Size = new Size(140, 36) };
            btnMarkRead.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnMarkRead.Click += delegate { MarkSelectedRead(); };

            btnRefresh = new Button { Text = "Refresh", Location = new Point(164, 410), Size = new Size(100, 36) };
            btnRefresh.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnRefresh.Click += delegate { LoadNotifications(); };

            btnClose = new Button { Text = "Back", Location = new Point(this.ClientSize.Width - 116, 410), Size = new Size(100, 36) };
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Click += delegate { this.Close(); };

            this.Controls.Add(lblTitle);
            this.Controls.Add(grid);
            this.Controls.Add(lblCount);
            this.Controls.Add(btnMarkRead);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(btnClose);
        }

        private void LoadNotifications()
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT n.NotificationID, n.Message, " +
                    "       ISNULL(p.ProductName,'') AS Product, " +
                    "       ISNULL(u.FullName,'') AS [Reported By], " +
                    "       n.CreatedAt AS [Date/Time], " +
                    "       CASE WHEN n.IsRead = 1 THEN 'Read' ELSE 'NEW' END AS Status " +
                    "FROM Notifications n " +
                    "LEFT JOIN Products p ON p.ProductID = n.ProductID " +
                    "LEFT JOIN Users u ON u.UserID = n.CreatedBy " +
                    "ORDER BY n.CreatedAt DESC");

                grid.DataSource = table;
                if (grid.Columns.Contains("NotificationID")) grid.Columns["NotificationID"].Visible = false;

                int unread = 0;
                foreach (DataGridViewRow row in grid.Rows)
                {
                    if (row.Cells["Status"].Value != null && row.Cells["Status"].Value.ToString() == "NEW")
                    {
                        row.DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 205);
                        row.DefaultCellStyle.Font = new Font(grid.Font, FontStyle.Bold);
                        unread++;
                    }
                }

                lblCount.Text = table.Rows.Count + " notification(s), " + unread + " unread";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load notifications: " + ex.Message, "Notifications",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MarkSelectedRead()
        {
            if (grid.CurrentRow == null)
            {
                MessageBox.Show("Please select a notification first.", "Notifications",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                int id = Convert.ToInt32(grid.CurrentRow.Cells["NotificationID"].Value);
                DB.Execute("UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @id", DB.P("@id", id));
                LoadNotifications();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Notifications",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
