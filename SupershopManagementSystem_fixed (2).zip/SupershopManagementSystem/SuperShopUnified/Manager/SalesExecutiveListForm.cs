using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public class SalesExecutiveListForm : Form
    {
        private DataGridView grid;
        private Button btnViewSales;
        private Button btnRefresh;
        private Button btnClose;
        private Label lblTitle;

        public SalesExecutiveListForm()
        {
            BuildUi();
            this.Load += delegate { LoadExecutives(); };
        }

        private void BuildUi()
        {
            this.Text = "Sales Executives";
            this.Width = 760;
            this.Height = 480;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MinimizeBox = false;
            this.MaximizeBox = false;

            lblTitle = new Label
            {
                Text = "Sales Executives",
                Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(16, 12)
            };

            grid = new DataGridView
            {
                Location = new Point(16, 50),
                Size = new Size(this.ClientSize.Width - 32, 330),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            grid.CellDoubleClick += delegate { OpenSelected(); };

            btnRefresh = new Button { Text = "Refresh", Location = new Point(16, 392), Size = new Size(100, 36) };
            btnRefresh.Click += delegate { LoadExecutives(); };

            btnViewSales = new Button
            {
                Text = "View Sales Data",
                Location = new Point(126, 392),
                Size = new Size(160, 36),
                BackColor = Color.MediumPurple,
                ForeColor = Color.White
            };
            btnViewSales.Click += delegate { OpenSelected(); };

            btnClose = new Button { Text = "Back", Location = new Point(this.ClientSize.Width - 116, 392), Size = new Size(100, 36) };
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Click += delegate { this.Close(); };

            this.Controls.Add(lblTitle);
            this.Controls.Add(grid);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(btnViewSales);
            this.Controls.Add(btnClose);
        }

        private void LoadExecutives()
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT u.UserID, u.FullName AS [Full Name], u.Username, u.Email, " +
                    "       (SELECT COUNT(*) FROM Sales s WHERE s.UserID = u.UserID) AS [Total Sales], " +
                    "       ISNULL((SELECT SUM(s.TotalAmount) FROM Sales s WHERE s.UserID = u.UserID), 0) AS [Total Revenue] " +
                    "FROM Users u " +
                    "WHERE u.Role = 'SalesExecutive' " +
                    "ORDER BY u.FullName");

                grid.DataSource = table;
                if (grid.Columns.Contains("UserID")) grid.Columns["UserID"].Visible = false;
                if (grid.Columns.Contains("Total Revenue"))
                    grid.Columns["Total Revenue"].DefaultCellStyle.Format = "N2";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load Sales Executives: " + ex.Message, "Sales Executives",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenSelected()
        {
            if (grid.CurrentRow == null)
            {
                MessageBox.Show("Please select a Sales Executive first.", "View Sales Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int userId = Convert.ToInt32(grid.CurrentRow.Cells["UserID"].Value);
            string name = grid.CurrentRow.Cells["Full Name"].Value.ToString();

            using (ManagerSalesHistoryForm form = new ManagerSalesHistoryForm(userId, "Sales Data - " + name))
            {
                form.ShowDialog();
            }
        }
    }
}
