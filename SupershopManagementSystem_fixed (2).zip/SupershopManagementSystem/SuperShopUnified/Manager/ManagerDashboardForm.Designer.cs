namespace SuperShopUnified
{
    partial class ManagerDashboardForm
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerDashboardForm));
            this.label1 = new System.Windows.Forms.Label();
            this.btnup = new System.Windows.Forms.Button();
            this.btncp = new System.Windows.Forms.Button();
            this.btnsl = new System.Windows.Forms.Button();
            this.btnsel = new System.Windows.Forms.Button();
            this.btni = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();

            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(269, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(303, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manager Dashboard";

            this.btnup.BackColor = System.Drawing.Color.MediumPurple;
            this.btnup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnup.Location = new System.Drawing.Point(49, 200);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(114, 54);
            this.btnup.TabIndex = 1;
            this.btnup.Text = "Update Profile";
            this.btnup.UseVisualStyleBackColor = false;
            this.btnup.Click += new System.EventHandler(this.btnup_Click);

            this.btncp.BackColor = System.Drawing.Color.MediumPurple;
            this.btncp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncp.Location = new System.Drawing.Point(49, 285);
            this.btncp.Name = "btncp";
            this.btncp.Size = new System.Drawing.Size(114, 66);
            this.btncp.TabIndex = 2;
            this.btncp.Text = "Change Password";
            this.btncp.UseVisualStyleBackColor = false;
            this.btncp.Click += new System.EventHandler(this.btncp_Click);

            this.btnsl.BackColor = System.Drawing.Color.MediumPurple;
            this.btnsl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsl.Location = new System.Drawing.Point(49, 114);
            this.btnsl.Name = "btnsl";
            this.btnsl.Size = new System.Drawing.Size(114, 55);
            this.btnsl.TabIndex = 3;
            this.btnsl.Text = "Sales History";
            this.btnsl.UseVisualStyleBackColor = false;
            this.btnsl.Click += new System.EventHandler(this.button1_Click);

            this.btnsel.BackColor = System.Drawing.Color.MediumPurple;
            this.btnsel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsel.Location = new System.Drawing.Point(203, 158);
            this.btnsel.Name = "btnsel";
            this.btnsel.Size = new System.Drawing.Size(118, 55);
            this.btnsel.TabIndex = 4;
            this.btnsel.Text = "View SE List";
            this.btnsel.UseVisualStyleBackColor = false;
            this.btnsel.Click += new System.EventHandler(this.btnsel_Click);

            this.btni.BackColor = System.Drawing.Color.MediumPurple;
            this.btni.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btni.Location = new System.Drawing.Point(203, 247);
            this.btni.Name = "btni";
            this.btni.Size = new System.Drawing.Size(118, 54);
            this.btni.TabIndex = 5;
            this.btni.Text = "Stocks";
            this.btni.UseVisualStyleBackColor = false;
            this.btni.Click += new System.EventHandler(this.btni_Click);

            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(490, 114);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(338, 339);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;

            this.button1.BackColor = System.Drawing.Color.Cyan;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(715, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 39);
            this.button1.TabIndex = 7;
            this.button1.Text = "Notifications";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);

            this.btnLogout.BackColor = System.Drawing.Color.IndianRed;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(715, 76);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(113, 39);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(860, 493);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btni);
            this.Controls.Add(this.btnsel);
            this.Controls.Add(this.btnsl);
            this.Controls.Add(this.btncp);
            this.Controls.Add(this.btnup);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Manager Page";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Button btncp;
        private System.Windows.Forms.Button btnsl;
        private System.Windows.Forms.Button btnsel;
        private System.Windows.Forms.Button btni;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnLogout;
    }
}
