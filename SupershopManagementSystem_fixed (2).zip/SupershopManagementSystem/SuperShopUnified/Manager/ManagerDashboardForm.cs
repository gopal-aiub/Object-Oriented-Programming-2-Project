using System.Windows.Forms;

namespace SuperShopUnified
{

    public partial class ManagerDashboardForm : Form
    {

        public Login CallerLogin { get; set; }

        public ManagerDashboardForm()
        {
            InitializeComponent();
            this.Text = "Manager Dashboard - Welcome, " + Session.FullName;
            this.btnLogout.Click += btnLogout_Click;
        }

        private void btnLogout_Click(object sender, System.EventArgs e)
        {
            if (MessageBox.Show("Do you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            Session.Clear();

            if (CallerLogin != null)
                CallerLogin.ShowLoginAgain();
            else
                new Login().Show();

            this.Close();
        }

        private void btnup_Click(object sender, System.EventArgs e)
        {
            using (profile form = new profile()) { form.ShowDialog(); }
        }

        private void btncp_Click(object sender, System.EventArgs e)
        {
            using (Edit_Password form = new Edit_Password()) { form.ShowDialog(); }
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            using (ManagerSalesHistoryForm form = new ManagerSalesHistoryForm(0, "All Sales - Every Executive"))
            {
                form.ShowDialog();
            }
        }

        private void btnsel_Click(object sender, System.EventArgs e)
        {
            using (SalesExecutiveListForm form = new SalesExecutiveListForm()) { form.ShowDialog(); }
        }

        private void btni_Click(object sender, System.EventArgs e)
        {
            using (ManagerStockManage form = new ManagerStockManage()) { form.ShowDialog(); }
        }

        private void button1_Click_1(object sender, System.EventArgs e)
        {
            using (NotificationsForm form = new NotificationsForm()) { form.ShowDialog(); }
        }
    }
}
