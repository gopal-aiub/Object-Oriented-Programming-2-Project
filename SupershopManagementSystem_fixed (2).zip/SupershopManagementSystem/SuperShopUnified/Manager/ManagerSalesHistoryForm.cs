using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public class ManagerSalesHistoryForm : Form
    {
        private readonly int userId;
        private DataGridView grid;
        private Label lblTitle;
        private Label lblTotals;
        private Button btnRefresh;
        private Button btnClose;

        public ManagerSalesHistoryForm(int userId, string title)
        {
            this.userId = userId;
            BuildUi(title);
            this.Load += delegate { LoadSales(); };
        }

        private void BuildUi(string title)
        {
            this.Text = title;
            this.Width = 900;
            this.Height = 520;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MinimizeBox = false;
            this.MaximizeBox = false;

            lblTitle = new Label
            {
                Text = title,
                Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(16, 12)
            };

            grid = new DataGridView
            {
                Location = new Point(16, 50),
                Size = new Size(this.ClientSize.Width - 32, 360),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };

            lblTotals = new Label
            {
                Location = new Point(16, 420),
                AutoSize = true,
                Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold)
            };

            btnRefresh = new Button { Text = "Refresh", Location = new Point(16, 448), Size = new Size(100, 36) };
            btnRefresh.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnRefresh.Click += delegate { LoadSales(); };

            btnClose = new Button { Text = "Back", Location = new Point(this.ClientSize.Width - 116, 448), Size = new Size(100, 36) };
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Click += delegate { this.Close(); };

            this.Controls.Add(lblTitle);
            this.Controls.Add(grid);
            this.Controls.Add(lblTotals);
            this.Controls.Add(btnRefresh);
            this.Controls.Add(btnClose);
        }

        private void LoadSales()
        {
            try
            {
                DataTable table;

                if (userId == 0)
                {
                    table = DB.GetTable(
                        "SELECT s.InvoiceNo AS [Invoice No], u.FullName AS [Sales Executive], " +
                        "       ISNULL(s.CustomerName,'') AS Customer, " +
                        "       s.SubTotal AS [Sub Total], s.DiscountAmount AS Discount, s.TotalAmount AS Total, " +
                        "       ISNULL(s.PaymentMethod,'') AS Payment, s.SaleDate AS [Date] " +
                        "FROM Sales s " +
                        "INNER JOIN Users u ON u.UserID = s.UserID " +
                        "ORDER BY s.SaleID DESC");
                }
                else
                {
                    table = DB.GetTable(
                        "SELECT s.InvoiceNo AS [Invoice No], " +
                        "       ISNULL(s.CustomerName,'') AS Customer, " +
                        "       s.SubTotal AS [Sub Total], s.DiscountAmount AS Discount, s.TotalAmount AS Total, " +
                        "       ISNULL(s.PaymentMethod,'') AS Payment, s.SaleDate AS [Date] " +
                        "FROM Sales s " +
                        "WHERE s.UserID = @uid " +
                        "ORDER BY s.SaleID DESC",
                        DB.P("@uid", userId));
                }

                grid.DataSource = table;
                foreach (string col in new[] { "Sub Total", "Discount", "Total" })
                    if (grid.Columns.Contains(col))
                        grid.Columns[col].DefaultCellStyle.Format = "N2";

                decimal total = 0;
                foreach (DataRow row in table.Rows) total += Convert.ToDecimal(row["Total"]);

                lblTotals.Text = table.Rows.Count + " sale(s)   |   Total revenue: " + total.ToString("N2");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load sales: " + ex.Message, "Sales History",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
