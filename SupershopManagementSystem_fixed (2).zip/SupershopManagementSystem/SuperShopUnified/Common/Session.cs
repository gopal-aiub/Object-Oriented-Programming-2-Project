namespace SuperShopUnified
{

    static class Session
    {
        public static int UserId = 0;
        public static string FullName = "";
        public static string Username = "";
        public static string Email = "";

        public static string Role = "";

        public static bool IsAdmin { get { return Role == "Admin"; } }
        public static bool IsManager { get { return Role == "Manager"; } }
        public static bool IsSalesExecutive { get { return Role == "SalesExecutive"; } }

        public static void Clear()
        {
            UserId = 0;
            FullName = "";
            Username = "";
            Email = "";
            Role = "";
        }
    }
}
