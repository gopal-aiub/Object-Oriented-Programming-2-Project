using System.Security.Cryptography;
using System.Text;

namespace SuperShopUnified
{
    static class Security
    {

        public static string Hash(string password)
        {
            if (password == null) password = "";
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder text = new StringBuilder();
                foreach (byte b in bytes) text.Append(b.ToString("x2"));
                return text.ToString();
            }
        }
    }
}
