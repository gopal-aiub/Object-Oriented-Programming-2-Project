using System;

namespace SuperShopUnified
{
    static class AppEvents
    {
        public static event EventHandler SaleSaved;

        public static void RaiseSaleSaved()
        {
            if (SaleSaved != null) SaleSaved(null, EventArgs.Empty);
        }
    }
}
