using System;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class ForgotPass : Form
    {

        public Login CallerLogin { get; set; }

        public ForgotPass()
        {
            InitializeComponent();
            this.txtnewpass.PasswordChar = '*';
            this.txtconfirmpass.PasswordChar = '*';
            this.btnback.Click += delegate { BackToLogin(); };
        }

        private void BackToLogin()
        {
            if (CallerLogin != null)
                CallerLogin.ShowLoginAgain();
            else
                new Login().Show();

            this.Close();
        }

        private void btnconfirm_Click(object sender, EventArgs e)
        {
            if (txtemail.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Your Email!");
                return;
            }

            if (txtnewpass.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter New Password!");
                return;
            }

            if (txtconfirmpass.Text.Trim() == "")
            {
                MessageBox.Show("Please Confirm Your Password!");
                return;
            }

            if (txtnewpass.Text.Trim() != txtconfirmpass.Text.Trim())
            {
                MessageBox.Show("New Password and Confirm Password do not match!");
                return;
            }

            try
            {
                object exists = DB.Scalar("SELECT COUNT(*) FROM Users WHERE Email = @email",
                    DB.P("@email", txtemail.Text.Trim()));

                if (Convert.ToInt32(exists) == 0)
                {
                    MessageBox.Show("This Email is not registered!");
                    return;
                }

                DB.Execute("UPDATE Users SET PasswordHash = @newpass WHERE Email = @email",
                    DB.P("@newpass", Security.Hash(txtnewpass.Text.Trim())),
                    DB.P("@email", txtemail.Text.Trim()));

                MessageBox.Show("Password Changed Successfully!");

                txtemail.Text = "";
                txtnewpass.Text = "";
                txtconfirmpass.Text = "";

                BackToLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
        }
    }
}
