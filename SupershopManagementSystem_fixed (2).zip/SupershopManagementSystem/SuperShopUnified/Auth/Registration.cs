using System;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
            this.btnback.Click += btnback_Click;
        }

        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void radioButton3_CheckedChanged(object sender, EventArgs e) { }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            if (txtusername.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Username!");
                return;
            }

            if (txtemail.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Email!");
                return;
            }

            if (txtpassword.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Password!");
                return;
            }

            if (txtphone.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Phone Number!");
                return;
            }

            string gender = "";
            if (rbmale.Checked) gender = "M";
            else if (rbfemale.Checked) gender = "F";
            else if (rbothers.Checked) gender = "Others";
            else
            {
                MessageBox.Show("Please Select Gender!");
                return;
            }

            if (cmbrole.SelectedItem == null)
            {
                MessageBox.Show("Please Select a Role!");
                return;
            }
            string role = cmbrole.SelectedItem.ToString();

            try
            {
                object exists = DB.Scalar("SELECT COUNT(*) FROM Users WHERE Email = @email",
                    DB.P("@email", txtemail.Text.Trim()));

                if (Convert.ToInt32(exists) > 0)
                {
                    MessageBox.Show("This Email is already registered!");
                    return;
                }

                string passwordHash = Security.Hash(txtpassword.Text.Trim());

                DB.Execute(
                    "INSERT INTO Users (FullName, Username, Email, PasswordHash, Gender, Phone, Role, IsActive) " +
                    "VALUES (@fullname, @username, @email, @pass, @gender, @phone, @role, 1)",
                    DB.P("@fullname", txtusername.Text.Trim()),
                    DB.P("@username", txtusername.Text.Trim()),
                    DB.P("@email", txtemail.Text.Trim()),
                    DB.P("@pass", passwordHash),
                    DB.P("@gender", gender),
                    DB.P("@phone", txtphone.Text.Trim()),
                    DB.P("@role", role));

                MessageBox.Show("Registration Successful! Please Login.");

                txtusername.Text = "";
                txtemail.Text = "";
                txtpassword.Text = "";
                txtphone.Text = "";
                rbmale.Checked = false;
                rbfemale.Checked = false;
                rbothers.Checked = false;
                cmbrole.SelectedIndex = -1;

                Login login = new Login();
                login.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
    }
}
