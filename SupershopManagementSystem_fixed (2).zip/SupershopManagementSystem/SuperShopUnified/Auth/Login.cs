using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            lblerorremail.Text = lblerorrpass.Text = "";

            if (txtemail.Text.Trim() == "")
                lblerorremail.Text = "Please Enter Your Email!";

            if (txtpass.Text.Trim() == "")
                lblerorrpass.Text = "Please Enter Password!";

            if (txtemail.Text.Trim() == "" || txtpass.Text.Trim() == "")
                return;

            if (cmbRole.SelectedItem == null)
            {
                MessageBox.Show("Please Select a Role!");
                return;
            }

            string role = cmbRole.SelectedItem.ToString();
            string email = txtemail.Text.Trim();
            string passwordHash = Security.Hash(txtpass.Text.Trim());

            try
            {
                DataTable table = DB.GetTable(
                    "SELECT UserID, FullName, Username, Email, Role " +
                    "FROM Users WHERE Email = @email AND PasswordHash = @pass AND Role = @role AND IsActive = 1",
                    DB.P("@email", email), DB.P("@pass", passwordHash), DB.P("@role", role));

                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("Invalid email, password or role.", "Login Failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DataRow row = table.Rows[0];

                Session.UserId = Convert.ToInt32(row["UserID"]);
                Session.FullName = row["FullName"].ToString();
                Session.Username = row["Username"].ToString();
                Session.Email = row["Email"].ToString();
                Session.Role = row["Role"].ToString();

                MessageBox.Show("Successfully Logged In", "Welcome",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                OpenDashboardForRole(Session.Role);
                this.Hide();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "Could not connect to the database.\n\n" +
                    "Please check:\n" +
                    "1. SQL Server is installed and running on this PC.\n" +
                    "2. The Data Source in App.config (SuperShopUnified.exe.config) " +
                    "matches your SQL Server instance name.\n" +
                    "3. You have run Database\\CreateDatabase.sql at least once.\n\n" +
                    "Technical detail: " + ex.Message,
                    "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected Error: " + ex.Message);
            }
        }

        private void OpenDashboardForRole(string role)
        {
            switch (role)
            {
                case "Admin":
                    {
                        AdminDashboard dash = new AdminDashboard();
                        dash.CallerLogin = this;
                        dash.Show();
                        break;
                    }
                case "Manager":
                    {
                        ManagerDashboardForm dash = new ManagerDashboardForm();
                        dash.CallerLogin = this;
                        dash.Show();
                        break;
                    }
                case "SalesExecutive":
                    {
                        MainMenu menu = new MainMenu();
                        menu.CallerLogin = this;
                        menu.Show();
                        break;
                    }
                default:
                    MessageBox.Show("Unknown role: " + role);
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Registration r = new Registration();
            r.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPass fp = new ForgotPass();
            fp.CallerLogin = this;
            fp.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            txtpass.PasswordChar = ckbox.Checked ? '\0' : '*';
        }

        public void ShowLoginAgain()
        {
            txtpass.Text = "";
            this.Show();
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {
        }

        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
