namespace SuperShopUnified
{
    partial class MainMenu
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btncart = new System.Windows.Forms.Button();
            this.btnprofile = new System.Windows.Forms.Button();
            this.btnstock = new System.Windows.Forms.Button();
            this.btnsaleshistory = new System.Windows.Forms.Button();
            this.btnlogout = new System.Windows.Forms.Button();
            this.lblnotification = new System.Windows.Forms.Label();
            this.pnlmenu1 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();

            this.btncart.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btncart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncart.Location = new System.Drawing.Point(426, 267);
            this.btncart.Name = "btncart";
            this.btncart.Size = new System.Drawing.Size(144, 74);
            this.btncart.TabIndex = 0;
            this.btncart.Text = "Cart";
            this.btncart.UseVisualStyleBackColor = false;
            this.btncart.Click += new System.EventHandler(this.btncart_Click_1);

            this.btnprofile.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnprofile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprofile.Location = new System.Drawing.Point(628, 134);
            this.btnprofile.Name = "btnprofile";
            this.btnprofile.Size = new System.Drawing.Size(140, 75);
            this.btnprofile.TabIndex = 1;
            this.btnprofile.Text = "Profile";
            this.btnprofile.UseVisualStyleBackColor = false;

            this.btnstock.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstock.Location = new System.Drawing.Point(624, 267);
            this.btnstock.Name = "btnstock";
            this.btnstock.Size = new System.Drawing.Size(144, 74);
            this.btnstock.TabIndex = 2;
            this.btnstock.Text = "Stock";
            this.btnstock.UseVisualStyleBackColor = false;

            this.btnsaleshistory.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnsaleshistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaleshistory.Location = new System.Drawing.Point(426, 135);
            this.btnsaleshistory.Name = "btnsaleshistory";
            this.btnsaleshistory.Size = new System.Drawing.Size(166, 74);
            this.btnsaleshistory.TabIndex = 3;
            this.btnsaleshistory.Text = "Sales History";
            this.btnsaleshistory.UseVisualStyleBackColor = false;

            this.btnlogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Location = new System.Drawing.Point(538, 382);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(121, 59);
            this.btnlogout.TabIndex = 4;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.UseVisualStyleBackColor = false;

            this.lblnotification.AutoSize = true;
            this.lblnotification.Location = new System.Drawing.Point(126, 89);
            this.lblnotification.Name = "lblnotification";
            this.lblnotification.Size = new System.Drawing.Size(0, 16);
            this.lblnotification.TabIndex = 5;

            this.pnlmenu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pnlmenu1.Location = new System.Drawing.Point(0, -2);
            this.pnlmenu1.Name = "pnlmenu1";
            this.pnlmenu1.Size = new System.Drawing.Size(804, 69);
            this.pnlmenu1.TabIndex = 6;

            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Location = new System.Drawing.Point(0, 462);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 81);
            this.panel1.TabIndex = 7;

            this.pictureBox1.Image = global::SuperShopUnified.Properties.Resources.salesexecutive;
            this.pictureBox1.Location = new System.Drawing.Point(0, 123);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 318);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.ClientSize = new System.Drawing.Size(800, 544);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlmenu1);
            this.Controls.Add(this.lblnotification);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.btnsaleshistory);
            this.Controls.Add(this.btnstock);
            this.Controls.Add(this.btnprofile);
            this.Controls.Add(this.btncart);
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncart;
        private System.Windows.Forms.Button btnprofile;
        private System.Windows.Forms.Button btnstock;
        private System.Windows.Forms.Button btnsaleshistory;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Label lblnotification;
        private System.Windows.Forms.Panel pnlmenu1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
