namespace SuperShopUnified
{
    partial class Edit_Password
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblpre1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnchngesave = new System.Windows.Forms.Button();
            this.btnchngebck = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();

            this.panel1.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(804, 123);
            this.panel1.TabIndex = 0;

            this.lblpre1.AutoSize = true;
            this.lblpre1.BackColor = System.Drawing.Color.Pink;
            this.lblpre1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpre1.Location = new System.Drawing.Point(96, 188);
            this.lblpre1.Name = "lblpre1";
            this.lblpre1.Size = new System.Drawing.Size(144, 25);
            this.lblpre1.TabIndex = 1;
            this.lblpre1.Text = "New Password";

            this.textBox1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.textBox1.Location = new System.Drawing.Point(255, 191);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(197, 22);
            this.textBox1.TabIndex = 2;

            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightPink;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 253);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Confirm Password";

            this.textBox2.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.textBox2.Location = new System.Drawing.Point(255, 256);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(197, 22);
            this.textBox2.TabIndex = 4;

            this.btnchngesave.BackColor = System.Drawing.Color.Lime;
            this.btnchngesave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchngesave.Location = new System.Drawing.Point(173, 326);
            this.btnchngesave.Name = "btnchngesave";
            this.btnchngesave.Size = new System.Drawing.Size(75, 55);
            this.btnchngesave.TabIndex = 5;
            this.btnchngesave.Text = "Save";
            this.btnchngesave.UseVisualStyleBackColor = false;

            this.btnchngebck.BackColor = System.Drawing.Color.Lime;
            this.btnchngebck.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchngebck.Location = new System.Drawing.Point(377, 326);
            this.btnchngebck.Name = "btnchngebck";
            this.btnchngebck.Size = new System.Drawing.Size(75, 55);
            this.btnchngebck.TabIndex = 6;
            this.btnchngebck.Text = "Back";
            this.btnchngebck.UseVisualStyleBackColor = false;

            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Pink;
            this.label2.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(215, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(335, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Change Your Password here";

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnchngebck);
            this.Controls.Add(this.btnchngesave);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblpre1);
            this.Controls.Add(this.panel1);
            this.Name = "Edit_Password";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit_Password";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblpre1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnchngesave;
        private System.Windows.Forms.Button btnchngebck;
        private System.Windows.Forms.Label label2;
    }
}