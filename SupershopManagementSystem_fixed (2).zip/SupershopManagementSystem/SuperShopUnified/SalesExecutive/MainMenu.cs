using System;
using System.Drawing;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class MainMenu : Form
    {
        private SalesHistory salesHistoryForm;

        public Login CallerLogin { get; set; }

        public MainMenu()
        {
            InitializeComponent();

            this.Text = "Welcome, " + Session.FullName +
                "   (User : " + Session.Username + ")";

            lblnotification.ForeColor = Color.Firebrick;

            this.btncart.Click += btncart_Click;
            this.btnprofile.Click += btnprofile_Click;
            this.btnstock.Click += btnstock_Click;
            this.btnsaleshistory.Click += btnsaleshistory_Click;
            this.btnlogout.Click += btnlogout_Click;
            this.Load += MainMenu_Load;
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            ShowLowStockMessage();
        }

        private void ShowLowStockMessage()
        {
            try
            {
                int low = Convert.ToInt32(DB.Scalar(
                    "SELECT COUNT(*) FROM Products WHERE IsActive = 1 AND StockQty <= ReorderLevel"));

                lblnotification.Text = low > 0
                    ? low + " product(s) are in LOW STOCK - open 'Stock' to notify the manager."
                    : "";
            }
            catch { lblnotification.Text = ""; }
        }

        private void btncart_Click(object sender, EventArgs e)
        {
            using (Cart form = new Cart()) { form.ShowDialog(); }
            ShowLowStockMessage();
        }

        private void btnsaleshistory_Click(object sender, EventArgs e)
        {
            if (salesHistoryForm == null || salesHistoryForm.IsDisposed)
            {
                salesHistoryForm = new SalesHistory();
                salesHistoryForm.Show(this);
            }
            else
            {
                salesHistoryForm.BringToFront();
            }
        }

        private void btnstock_Click(object sender, EventArgs e)
        {
            using (Stock form = new Stock()) { form.ShowDialog(); }
            ShowLowStockMessage();
        }

        private void btnprofile_Click(object sender, EventArgs e)
        {
            using (ProfileShow form = new ProfileShow()) { form.ShowDialog(); }
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit?", "Exit",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (salesHistoryForm != null && !salesHistoryForm.IsDisposed) salesHistoryForm.Close();

                Session.Clear();

                if (CallerLogin != null)
                    CallerLogin.ShowLoginAgain();
                else
                    new Login().Show();

                this.Close();
            }
        }

        private void btncart_Click_1(object sender, EventArgs e)
        {

        }
    }
}
