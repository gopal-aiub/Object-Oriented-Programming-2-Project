namespace SuperShopUnified
{
    partial class paymentMethod
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnbkash = new System.Windows.Forms.Button();
            this.btnnagad = new System.Windows.Forms.Button();
            this.btnbank = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlpay1 = new System.Windows.Forms.Panel();
            this.pnlpay2 = new System.Windows.Forms.Panel();
            this.SuspendLayout();

            this.btnbkash.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnbkash.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbkash.Location = new System.Drawing.Point(121, 197);
            this.btnbkash.Name = "btnbkash";
            this.btnbkash.Size = new System.Drawing.Size(105, 78);
            this.btnbkash.TabIndex = 0;
            this.btnbkash.Text = "Bkash";
            this.btnbkash.UseVisualStyleBackColor = false;

            this.btnnagad.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnnagad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnagad.Location = new System.Drawing.Point(280, 197);
            this.btnnagad.Name = "btnnagad";
            this.btnnagad.Size = new System.Drawing.Size(104, 78);
            this.btnnagad.TabIndex = 1;
            this.btnnagad.Text = "Nagad";
            this.btnnagad.UseVisualStyleBackColor = false;

            this.btnbank.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbank.Location = new System.Drawing.Point(439, 199);
            this.btnbank.Name = "btnbank";
            this.btnbank.Size = new System.Drawing.Size(109, 81);
            this.btnbank.TabIndex = 2;
            this.btnbank.Text = "Bank";
            this.btnbank.UseVisualStyleBackColor = false;

            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SpringGreen;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(206, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose payment method";

            this.pnlpay1.BackColor = System.Drawing.Color.Aquamarine;
            this.pnlpay1.Location = new System.Drawing.Point(-1, 0);
            this.pnlpay1.Name = "pnlpay1";
            this.pnlpay1.Size = new System.Drawing.Size(801, 78);
            this.pnlpay1.TabIndex = 4;
            this.pnlpay1.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlpay1_Paint);

            this.pnlpay2.BackColor = System.Drawing.Color.Aquamarine;
            this.pnlpay2.Location = new System.Drawing.Point(-1, 375);
            this.pnlpay2.Name = "pnlpay2";
            this.pnlpay2.Size = new System.Drawing.Size(801, 78);
            this.pnlpay2.TabIndex = 5;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlpay2);
            this.Controls.Add(this.pnlpay1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnbank);
            this.Controls.Add(this.btnnagad);
            this.Controls.Add(this.btnbkash);
            this.Name = "paymentMethod";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "paymentMethod";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbkash;
        private System.Windows.Forms.Button btnnagad;
        private System.Windows.Forms.Button btnbank;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlpay1;
        private System.Windows.Forms.Panel pnlpay2;
    }
}