namespace SuperShopUnified
{
    partial class ProfileShow
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblfullname1 = new System.Windows.Forms.Label();
            this.lblphone1 = new System.Windows.Forms.Label();
            this.lblemail1 = new System.Windows.Forms.Label();
            this.lblgender1 = new System.Windows.Forms.Label();
            this.lblusername1 = new System.Windows.Forms.Label();
            this.lblphone2 = new System.Windows.Forms.Label();
            this.lblemail2 = new System.Windows.Forms.Label();
            this.lblgender2 = new System.Windows.Forms.Label();
            this.lbluser2 = new System.Windows.Forms.Label();
            this.lblfull2 = new System.Windows.Forms.Label();
            this.btnprofileupdate = new System.Windows.Forms.Button();
            this.btnchangepass = new System.Windows.Forms.Button();
            this.btnbackprofileshow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblfullname1
            // 
            this.lblfullname1.AutoSize = true;
            this.lblfullname1.BackColor = System.Drawing.Color.RosyBrown;
            this.lblfullname1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfullname1.Location = new System.Drawing.Point(69, 88);
            this.lblfullname1.Name = "lblfullname1";
            this.lblfullname1.Size = new System.Drawing.Size(89, 18);
            this.lblfullname1.TabIndex = 0;
            this.lblfullname1.Text = "Full Name:";
            // 
            // lblphone1
            // 
            this.lblphone1.AutoSize = true;
            this.lblphone1.BackColor = System.Drawing.Color.RosyBrown;
            this.lblphone1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone1.Location = new System.Drawing.Point(107, 271);
            this.lblphone1.Name = "lblphone1";
            this.lblphone1.Size = new System.Drawing.Size(51, 16);
            this.lblphone1.TabIndex = 3;
            this.lblphone1.Text = "Phone";
            // 
            // lblemail1
            // 
            this.lblemail1.AutoSize = true;
            this.lblemail1.BackColor = System.Drawing.Color.RosyBrown;
            this.lblemail1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail1.Location = new System.Drawing.Point(112, 223);
            this.lblemail1.Name = "lblemail1";
            this.lblemail1.Size = new System.Drawing.Size(46, 16);
            this.lblemail1.TabIndex = 4;
            this.lblemail1.Text = "Email";
            // 
            // lblgender1
            // 
            this.lblgender1.AutoSize = true;
            this.lblgender1.BackColor = System.Drawing.Color.RosyBrown;
            this.lblgender1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender1.Location = new System.Drawing.Point(96, 183);
            this.lblgender1.Name = "lblgender1";
            this.lblgender1.Size = new System.Drawing.Size(62, 16);
            this.lblgender1.TabIndex = 5;
            this.lblgender1.Text = " Gender";
            // 
            // lblusername1
            // 
            this.lblusername1.AutoSize = true;
            this.lblusername1.BackColor = System.Drawing.Color.RosyBrown;
            this.lblusername1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername1.Location = new System.Drawing.Point(69, 140);
            this.lblusername1.Name = "lblusername1";
            this.lblusername1.Size = new System.Drawing.Size(89, 16);
            this.lblusername1.TabIndex = 6;
            this.lblusername1.Text = "User Name:";
            // 
            // lblphone2
            // 
            this.lblphone2.AutoSize = true;
            this.lblphone2.Location = new System.Drawing.Point(187, 271);
            this.lblphone2.Name = "lblphone2";
            this.lblphone2.Size = new System.Drawing.Size(0, 16);
            this.lblphone2.TabIndex = 8;
            // 
            // lblemail2
            // 
            this.lblemail2.AutoSize = true;
            this.lblemail2.Location = new System.Drawing.Point(187, 223);
            this.lblemail2.Name = "lblemail2";
            this.lblemail2.Size = new System.Drawing.Size(0, 16);
            this.lblemail2.TabIndex = 9;
            // 
            // lblgender2
            // 
            this.lblgender2.AutoSize = true;
            this.lblgender2.Location = new System.Drawing.Point(187, 183);
            this.lblgender2.Name = "lblgender2";
            this.lblgender2.Size = new System.Drawing.Size(0, 16);
            this.lblgender2.TabIndex = 10;
            // 
            // lbluser2
            // 
            this.lbluser2.AutoSize = true;
            this.lbluser2.Location = new System.Drawing.Point(187, 140);
            this.lbluser2.Name = "lbluser2";
            this.lbluser2.Size = new System.Drawing.Size(0, 16);
            this.lbluser2.TabIndex = 11;
            // 
            // lblfull2
            // 
            this.lblfull2.AutoSize = true;
            this.lblfull2.Location = new System.Drawing.Point(187, 90);
            this.lblfull2.Name = "lblfull2";
            this.lblfull2.Size = new System.Drawing.Size(0, 16);
            this.lblfull2.TabIndex = 12;
            // 
            // btnprofileupdate
            // 
            this.btnprofileupdate.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnprofileupdate.FlatAppearance.BorderSize = 2;
            this.btnprofileupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnprofileupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprofileupdate.Location = new System.Drawing.Point(519, 240);
            this.btnprofileupdate.Name = "btnprofileupdate";
            this.btnprofileupdate.Size = new System.Drawing.Size(172, 56);
            this.btnprofileupdate.TabIndex = 14;
            this.btnprofileupdate.Text = "Update profile";
            this.btnprofileupdate.UseVisualStyleBackColor = false;
            // 
            // btnchangepass
            // 
            this.btnchangepass.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnchangepass.FlatAppearance.BorderSize = 2;
            this.btnchangepass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnchangepass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchangepass.Location = new System.Drawing.Point(519, 317);
            this.btnchangepass.Name = "btnchangepass";
            this.btnchangepass.Size = new System.Drawing.Size(246, 41);
            this.btnchangepass.TabIndex = 15;
            this.btnchangepass.Text = "Change Password";
            this.btnchangepass.UseVisualStyleBackColor = false;
            // 
            // btnbackprofileshow
            // 
            this.btnbackprofileshow.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnbackprofileshow.FlatAppearance.BorderSize = 2;
            this.btnbackprofileshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbackprofileshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbackprofileshow.Location = new System.Drawing.Point(519, 397);
            this.btnbackprofileshow.Name = "btnbackprofileshow";
            this.btnbackprofileshow.Size = new System.Drawing.Size(163, 41);
            this.btnbackprofileshow.TabIndex = 16;
            this.btnbackprofileshow.Text = "Back";
            this.btnbackprofileshow.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.RosyBrown;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-3, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 22);
            this.label1.TabIndex = 18;
            this.label1.Text = "Employee Information";
            // 
            // ProfileShow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnbackprofileshow);
            this.Controls.Add(this.btnchangepass);
            this.Controls.Add(this.btnprofileupdate);
            this.Controls.Add(this.lblfull2);
            this.Controls.Add(this.lbluser2);
            this.Controls.Add(this.lblgender2);
            this.Controls.Add(this.lblemail2);
            this.Controls.Add(this.lblphone2);
            this.Controls.Add(this.lblusername1);
            this.Controls.Add(this.lblgender1);
            this.Controls.Add(this.lblemail1);
            this.Controls.Add(this.lblphone1);
            this.Controls.Add(this.lblfullname1);
            this.Name = "ProfileShow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProfileShow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfullname1;
        private System.Windows.Forms.Label lblphone1;
        private System.Windows.Forms.Label lblemail1;
        private System.Windows.Forms.Label lblgender1;
        private System.Windows.Forms.Label lblusername1;
        private System.Windows.Forms.Label lblphone2;
        private System.Windows.Forms.Label lblemail2;
        private System.Windows.Forms.Label lblgender2;
        private System.Windows.Forms.Label lbluser2;
        private System.Windows.Forms.Label lblfull2;
        private System.Windows.Forms.Button btnprofileupdate;
        private System.Windows.Forms.Button btnchangepass;
        private System.Windows.Forms.Button btnbackprofileshow;
        private System.Windows.Forms.Label label1;
    }
}