using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class Invoice : Form
    {
        public Invoice()
        {
            InitializeComponent();
            this.btnclose.Click += delegate { this.Close(); };
            this.StartPosition = FormStartPosition.CenterParent;
        }

        public Invoice(string invoiceText) : this()
        {
            richTextBox1.Text = invoiceText;
        }
    }
}
