using System;
using System.Data;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class ProfileShow : Form
    {
        public ProfileShow()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "My Profile";

            this.btnprofileupdate.Click += btnprofileupdate_Click;
            this.btnchangepass.Click += btnchangepass_Click;
            this.btnbackprofileshow.Click += delegate { this.Close(); };

            this.Load += ProfileShow_Load;
        }

        private void ProfileShow_Load(object sender, EventArgs e)
        {
            LoadProfile();
        }

        private void LoadProfile()
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT u.FullName, u.Username, ISNULL(u.Gender,'') AS Gender, " +
                    "       ISNULL(u.Email,'') AS Email, ISNULL(u.Phone,'') AS Phone " +
                    "FROM Users u " +
                    "WHERE u.UserID = @id", DB.P("@id", Session.UserId));

                if (table.Rows.Count == 0) return;
                DataRow row = table.Rows[0];

                lblfull2.Text = row["FullName"].ToString();
                lbluser2.Text = row["Username"].ToString();
                lblgender2.Text = row["Gender"].ToString();
                lblemail2.Text = row["Email"].ToString();
                lblphone2.Text = row["Phone"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load profile: " + ex.Message, "My Profile",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnprofileupdate_Click(object sender, EventArgs e)
        {
            using (profile form = new profile())
            {
                form.ShowDialog();
            }

            LoadProfile();
        }

        private void btnchangepass_Click(object sender, EventArgs e)
        {
            using (Edit_Password form = new Edit_Password())
            {
                form.ShowDialog();
            }
        }
    }
}
