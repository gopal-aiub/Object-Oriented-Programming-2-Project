using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SuperShopUnified
{
    public partial class paymentMethod : Form
    {

        public string Method = "";

        public string Info = "";

        public paymentMethod()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;

            this.btnbkash.Click += delegate { Choose("bKash"); };
            this.btnnagad.Click += delegate { Choose("Nagad"); };
            this.btnbank.Click += delegate { Choose("Bank"); };

            LoadButtonImage(btnbkash, "bKash-Logo.png");
            LoadButtonImage(btnnagad, "nagad.png");
            LoadButtonImage(btnbank, "bank1.png");
        }

        private void LoadButtonImage(Button btn, string fileName)
        {
            try
            {
                string path = Path.Combine(Application.StartupPath, "Images", fileName);
                if (File.Exists(path))
                {
                    btn.Image = Image.FromFile(path);
                    btn.ImageAlign = ContentAlignment.MiddleCenter;
                    btn.TextImageRelation = TextImageRelation.ImageAboveText;
                    btn.TextAlign = ContentAlignment.BottomCenter;
                }
            }
            catch
            {

            }
        }

        private void Choose(string method)
        {
            string info = Interaction.InputBox(
                "Please enter the customer's " + method + " number / transaction info:",
                "Payment - " + method, "");

            if (info.Trim() == "")
            {
                MessageBox.Show("Please enter your " + method + " info.", "Payment",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Method = method;
            Info = info.Trim();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void pnlpay1_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
