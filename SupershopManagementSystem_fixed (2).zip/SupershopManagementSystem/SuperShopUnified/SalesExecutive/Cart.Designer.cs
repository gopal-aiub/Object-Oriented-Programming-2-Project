namespace SuperShopUnified
{
    partial class Cart
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblcoustomername = new System.Windows.Forms.Label();
            this.lblsearchproduct = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnshowall = new System.Windows.Forms.Button();
            this.lblproduct = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblcartitem = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.lblquantity = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btnadd = new System.Windows.Forms.Button();
            this.lbldiscount = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.btnback = new System.Windows.Forms.Button();
            this.btninvoice = new System.Windows.Forms.Button();
            this.btnpay = new System.Windows.Forms.Button();
            this.btnremoveitem = new System.Windows.Forms.Button();
            this.btnclearcart = new System.Windows.Forms.Button();
            this.lblsb = new System.Windows.Forms.Label();
            this.lbldiscounttotal = new System.Windows.Forms.Label();
            this.lblgrandtotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbldis = new System.Windows.Forms.Label();
            this.lblgrand = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.SuspendLayout();

            this.lblcoustomername.AutoSize = true;
            this.lblcoustomername.BackColor = System.Drawing.Color.Aquamarine;
            this.lblcoustomername.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcoustomername.Location = new System.Drawing.Point(541, 15);
            this.lblcoustomername.Name = "lblcoustomername";
            this.lblcoustomername.Size = new System.Drawing.Size(126, 16);
            this.lblcoustomername.TabIndex = 0;
            this.lblcoustomername.Text = "Coustomer Name";

            this.lblsearchproduct.AutoSize = true;
            this.lblsearchproduct.BackColor = System.Drawing.Color.Khaki;
            this.lblsearchproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearchproduct.Location = new System.Drawing.Point(12, 18);
            this.lblsearchproduct.Name = "lblsearchproduct";
            this.lblsearchproduct.Size = new System.Drawing.Size(113, 16);
            this.lblsearchproduct.TabIndex = 1;
            this.lblsearchproduct.Text = "Search Product";

            this.lblphone.AutoSize = true;
            this.lblphone.BackColor = System.Drawing.Color.SkyBlue;
            this.lblphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone.Location = new System.Drawing.Point(616, 55);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(51, 16);
            this.lblphone.TabIndex = 2;
            this.lblphone.Text = "Phone";

            this.textBox1.BackColor = System.Drawing.Color.LightGreen;
            this.textBox1.Location = new System.Drawing.Point(673, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);

            this.textBox2.BackColor = System.Drawing.Color.LightGreen;
            this.textBox2.Location = new System.Drawing.Point(673, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 4;

            this.textBox3.BackColor = System.Drawing.Color.LightGreen;
            this.textBox3.Location = new System.Drawing.Point(131, 15);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 5;

            this.btnsearch.BackColor = System.Drawing.Color.BurlyWood;
            this.btnsearch.FlatAppearance.BorderSize = 2;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(253, 18);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 30);
            this.btnsearch.TabIndex = 6;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;

            this.btnshowall.BackColor = System.Drawing.Color.BurlyWood;
            this.btnshowall.FlatAppearance.BorderSize = 2;
            this.btnshowall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnshowall.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshowall.Location = new System.Drawing.Point(349, 18);
            this.btnshowall.Name = "btnshowall";
            this.btnshowall.Size = new System.Drawing.Size(75, 30);
            this.btnshowall.TabIndex = 7;
            this.btnshowall.Text = "Show All";
            this.btnshowall.UseVisualStyleBackColor = false;

            this.lblproduct.AutoSize = true;
            this.lblproduct.BackColor = System.Drawing.Color.LightSalmon;
            this.lblproduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproduct.Location = new System.Drawing.Point(12, 70);
            this.lblproduct.Name = "lblproduct";
            this.lblproduct.Size = new System.Drawing.Size(74, 20);
            this.lblproduct.TabIndex = 8;
            this.lblproduct.Text = "Product";
            this.lblproduct.Click += new System.EventHandler(this.label1_Click);

            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 105);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(399, 278);
            this.dataGridView1.TabIndex = 9;

            this.lblcartitem.AutoSize = true;
            this.lblcartitem.BackColor = System.Drawing.Color.LightSalmon;
            this.lblcartitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcartitem.Location = new System.Drawing.Point(441, 70);
            this.lblcartitem.Name = "lblcartitem";
            this.lblcartitem.Size = new System.Drawing.Size(87, 20);
            this.lblcartitem.TabIndex = 10;
            this.lblcartitem.Text = "Cart Item";
            this.lblcartitem.Click += new System.EventHandler(this.lblcartitem_Click);

            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(430, 107);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(358, 276);
            this.dataGridView2.TabIndex = 11;

            this.lblquantity.AutoSize = true;
            this.lblquantity.BackColor = System.Drawing.Color.PeachPuff;
            this.lblquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquantity.Location = new System.Drawing.Point(33, 403);
            this.lblquantity.Name = "lblquantity";
            this.lblquantity.Size = new System.Drawing.Size(63, 16);
            this.lblquantity.TabIndex = 12;
            this.lblquantity.Text = "Quantity";

            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(119, 404);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(65, 22);
            this.numericUpDown1.TabIndex = 13;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);

            this.btnadd.BackColor = System.Drawing.Color.BurlyWood;
            this.btnadd.FlatAppearance.BorderSize = 2;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(226, 400);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 32);
            this.btnadd.TabIndex = 14;
            this.btnadd.Text = "ADD";
            this.btnadd.UseVisualStyleBackColor = false;

            this.lbldiscount.AutoSize = true;
            this.lbldiscount.BackColor = System.Drawing.Color.Coral;
            this.lbldiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscount.Location = new System.Drawing.Point(25, 477);
            this.lbldiscount.Name = "lbldiscount";
            this.lbldiscount.Size = new System.Drawing.Size(100, 20);
            this.lbldiscount.TabIndex = 16;
            this.lbldiscount.Text = "Discount%";

            this.numericUpDown2.DecimalPlaces = 2;
            this.numericUpDown2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown2.Location = new System.Drawing.Point(131, 477);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(65, 22);
            this.numericUpDown2.TabIndex = 17;

            this.btnback.BackColor = System.Drawing.Color.BurlyWood;
            this.btnback.FlatAppearance.BorderSize = 2;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(264, 520);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 32);
            this.btnback.TabIndex = 18;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;

            this.btninvoice.BackColor = System.Drawing.Color.BurlyWood;
            this.btninvoice.FlatAppearance.BorderSize = 2;
            this.btninvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvoice.Location = new System.Drawing.Point(156, 520);
            this.btninvoice.Name = "btninvoice";
            this.btninvoice.Size = new System.Drawing.Size(75, 32);
            this.btninvoice.TabIndex = 19;
            this.btninvoice.Text = "Print Invoice";
            this.btninvoice.UseVisualStyleBackColor = false;

            this.btnpay.BackColor = System.Drawing.Color.BurlyWood;
            this.btnpay.FlatAppearance.BorderSize = 2;
            this.btnpay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpay.Location = new System.Drawing.Point(36, 523);
            this.btnpay.Name = "btnpay";
            this.btnpay.Size = new System.Drawing.Size(89, 32);
            this.btnpay.TabIndex = 20;
            this.btnpay.Text = "Payment Method";
            this.btnpay.UseVisualStyleBackColor = false;

            this.btnremoveitem.BackColor = System.Drawing.Color.BurlyWood;
            this.btnremoveitem.FlatAppearance.BorderSize = 2;
            this.btnremoveitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnremoveitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremoveitem.Location = new System.Drawing.Point(503, 389);
            this.btnremoveitem.Name = "btnremoveitem";
            this.btnremoveitem.Size = new System.Drawing.Size(105, 34);
            this.btnremoveitem.TabIndex = 21;
            this.btnremoveitem.Text = "  Remove Item";
            this.btnremoveitem.UseVisualStyleBackColor = false;

            this.btnclearcart.BackColor = System.Drawing.Color.BurlyWood;
            this.btnclearcart.FlatAppearance.BorderSize = 2;
            this.btnclearcart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclearcart.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclearcart.Location = new System.Drawing.Point(673, 389);
            this.btnclearcart.Name = "btnclearcart";
            this.btnclearcart.Size = new System.Drawing.Size(95, 37);
            this.btnclearcart.TabIndex = 22;
            this.btnclearcart.Text = "Clear Cart";
            this.btnclearcart.UseVisualStyleBackColor = false;

            this.lblsb.AutoSize = true;
            this.lblsb.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblsb.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsb.Location = new System.Drawing.Point(510, 441);
            this.lblsb.Name = "lblsb";
            this.lblsb.Size = new System.Drawing.Size(78, 16);
            this.lblsb.TabIndex = 23;
            this.lblsb.Text = "Sub Total:";
            this.lblsb.Click += new System.EventHandler(this.lblsb_Click);

            this.lbldiscounttotal.AutoSize = true;
            this.lbldiscounttotal.BackColor = System.Drawing.Color.Plum;
            this.lbldiscounttotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscounttotal.Location = new System.Drawing.Point(517, 483);
            this.lbldiscounttotal.Name = "lbldiscounttotal";
            this.lbldiscounttotal.Size = new System.Drawing.Size(71, 16);
            this.lbldiscounttotal.TabIndex = 24;
            this.lbldiscounttotal.Text = "Discount:";

            this.lblgrandtotal.AutoSize = true;
            this.lblgrandtotal.BackColor = System.Drawing.Color.Cyan;
            this.lblgrandtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrandtotal.Location = new System.Drawing.Point(500, 520);
            this.lblgrandtotal.Name = "lblgrandtotal";
            this.lblgrandtotal.Size = new System.Drawing.Size(93, 16);
            this.lblgrandtotal.TabIndex = 25;
            this.lblgrandtotal.Text = "Grand Total:";

            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(657, 447);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "0.00";

            this.lbldis.AutoSize = true;
            this.lbldis.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldis.Location = new System.Drawing.Point(657, 483);
            this.lbldis.Name = "lbldis";
            this.lbldis.Size = new System.Drawing.Size(35, 16);
            this.lbldis.TabIndex = 27;
            this.lbldis.Text = "0.00";

            this.lblgrand.AutoSize = true;
            this.lblgrand.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrand.Location = new System.Drawing.Point(657, 520);
            this.lblgrand.Name = "lblgrand";
            this.lblgrand.Size = new System.Drawing.Size(35, 16);
            this.lblgrand.TabIndex = 28;
            this.lblgrand.Text = "0.00";

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 567);
            this.Controls.Add(this.lblgrand);
            this.Controls.Add(this.lbldis);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblgrandtotal);
            this.Controls.Add(this.lbldiscounttotal);
            this.Controls.Add(this.lblsb);
            this.Controls.Add(this.btnclearcart);
            this.Controls.Add(this.btnremoveitem);
            this.Controls.Add(this.btnpay);
            this.Controls.Add(this.btninvoice);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.lbldiscount);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.lblquantity);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.lblcartitem);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblproduct);
            this.Controls.Add(this.btnshowall);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.lblsearchproduct);
            this.Controls.Add(this.lblcoustomername);
            this.Name = "Cart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cart";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcoustomername;
        private System.Windows.Forms.Label lblsearchproduct;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnshowall;
        private System.Windows.Forms.Label lblproduct;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblcartitem;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label lblquantity;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label lbldiscount;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btninvoice;
        private System.Windows.Forms.Button btnpay;
        private System.Windows.Forms.Button btnremoveitem;
        private System.Windows.Forms.Button btnclearcart;
        private System.Windows.Forms.Label lblsb;
        private System.Windows.Forms.Label lbldiscounttotal;
        private System.Windows.Forms.Label lblgrandtotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbldis;
        private System.Windows.Forms.Label lblgrand;
    }
}