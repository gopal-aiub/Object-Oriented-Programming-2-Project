using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class Edit_Password : Form
    {
        public Edit_Password()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Change Password";

            textBox1.PasswordChar = '●';
            textBox2.PasswordChar = '●';

            this.btnchngesave.Click += btnchngesave_Click;
            this.btnchngebck.Click += delegate { this.Close(); };
        }

        private void btnchngesave_Click(object sender, EventArgs e)
        {
            string newPassword = textBox1.Text.Trim();
            string confirmPassword = textBox2.Text.Trim();

            if (newPassword == "")
            {
                MessageBox.Show("Please enter a new password.", "Change Password",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPassword.Length < 4)
            {
                MessageBox.Show("Password must be at least 4 characters long.", "Change Password",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Change Password",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string hashed = Security.Hash(newPassword);

                DB.Execute(
                    "UPDATE Users SET PasswordHash = @hash WHERE UserID = @id",
                    DB.P("@hash", hashed),
                    DB.P("@id", Session.UserId));

                MessageBox.Show("Password changed successfully.", "Change Password",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error changing password: " + ex.Message, "Change Password",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
