using System;
using System.Data;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class SalesHistory : Form
    {
        public SalesHistory()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "My Sales History";

            this.btnrefresh.Click += delegate { LoadSales(); };
            this.btnclose.Click += delegate { this.Close(); };
            this.Load += delegate { LoadSales(); };

            AppEvents.SaleSaved += SaleSavedHandler;
            this.FormClosed += delegate { AppEvents.SaleSaved -= SaleSavedHandler; };
        }

        private void SaleSavedHandler(object sender, EventArgs e)
        {
            if (this.InvokeRequired) { this.BeginInvoke((MethodInvoker)LoadSales); return; }
            LoadSales();
        }

        private void LoadSales()
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT s.InvoiceNo AS [Invoice No], ISNULL(s.CustomerName,'') AS Customer, " +
                    "       s.SubTotal AS [Sub Total], s.DiscountAmount AS Discount, " +
                    "       s.TotalAmount AS Total, ISNULL(s.PaymentMethod,'') AS Payment, " +
                    "       s.SaleDate AS [Date] " +
                    "FROM Sales s WHERE s.UserID = @uid ORDER BY s.SaleID DESC",
                    DB.P("@uid", Session.UserId));

                dataGridView1.DataSource = table;
                if (dataGridView1.Columns.Contains("Sub Total"))
                    dataGridView1.Columns["Sub Total"].DefaultCellStyle.Format = "N2";
                if (dataGridView1.Columns.Contains("Discount"))
                    dataGridView1.Columns["Discount"].DefaultCellStyle.Format = "N2";
                if (dataGridView1.Columns.Contains("Total"))
                    dataGridView1.Columns["Total"].DefaultCellStyle.Format = "N2";

                decimal total = 0;
                foreach (DataRow row in table.Rows)
                    total += Convert.ToDecimal(row["Total"]);

                lblsaleshow.Text = table.Rows.Count.ToString();
                lblamountshow.Text = total.ToString("N2");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load sales: " + ex.Message, "Sales History",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
