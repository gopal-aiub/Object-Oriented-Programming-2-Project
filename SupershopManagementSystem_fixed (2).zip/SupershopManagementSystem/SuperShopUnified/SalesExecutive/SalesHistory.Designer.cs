namespace SuperShopUnified
{
    partial class SalesHistory
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbltotalsale = new System.Windows.Forms.Label();
            this.lblsaleshow = new System.Windows.Forms.Label();
            this.lblamountshow = new System.Windows.Forms.Label();
            this.lbltotalamount = new System.Windows.Forms.Label();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();

            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(127, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(510, 205);
            this.dataGridView1.TabIndex = 0;

            this.lbltotalsale.AutoSize = true;
            this.lbltotalsale.BackColor = System.Drawing.Color.RosyBrown;
            this.lbltotalsale.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalsale.Location = new System.Drawing.Point(32, 325);
            this.lbltotalsale.Name = "lbltotalsale";
            this.lbltotalsale.Size = new System.Drawing.Size(79, 16);
            this.lbltotalsale.TabIndex = 1;
            this.lbltotalsale.Text = "Total Sale";

            this.lblsaleshow.AutoSize = true;
            this.lblsaleshow.Location = new System.Drawing.Point(124, 325);
            this.lblsaleshow.Name = "lblsaleshow";
            this.lblsaleshow.Size = new System.Drawing.Size(0, 16);
            this.lblsaleshow.TabIndex = 2;

            this.lblamountshow.AutoSize = true;
            this.lblamountshow.Location = new System.Drawing.Point(164, 395);
            this.lblamountshow.Name = "lblamountshow";
            this.lblamountshow.Size = new System.Drawing.Size(0, 16);
            this.lblamountshow.TabIndex = 3;

            this.lbltotalamount.AutoSize = true;
            this.lbltotalamount.BackColor = System.Drawing.Color.RosyBrown;
            this.lbltotalamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalamount.Location = new System.Drawing.Point(54, 395);
            this.lbltotalamount.Name = "lbltotalamount";
            this.lbltotalamount.Size = new System.Drawing.Size(98, 16);
            this.lbltotalamount.TabIndex = 4;
            this.lbltotalamount.Text = "Total Amount";

            this.btnrefresh.BackColor = System.Drawing.Color.RosyBrown;
            this.btnrefresh.FlatAppearance.BorderSize = 2;
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.Location = new System.Drawing.Point(345, 351);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(160, 60);
            this.btnrefresh.TabIndex = 5;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;

            this.btnclose.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnclose.FlatAppearance.BorderSize = 2;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(584, 351);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(125, 60);
            this.btnclose.TabIndex = 6;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = false;

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.lbltotalamount);
            this.Controls.Add(this.lblamountshow);
            this.Controls.Add(this.lblsaleshow);
            this.Controls.Add(this.lbltotalsale);
            this.Controls.Add(this.dataGridView1);
            this.Name = "SalesHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SalesHistory";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbltotalsale;
        private System.Windows.Forms.Label lblsaleshow;
        private System.Windows.Forms.Label lblamountshow;
        private System.Windows.Forms.Label lbltotalamount;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnclose;
    }
}