using System;
using System.Data;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class profile : Form
    {
        public profile()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;
            this.Text = "My Profile";

            txtusername.ReadOnly = true;

            this.btnsave.Click += btnsave_Click;
            this.btnback.Click += delegate { this.Close(); };
        }

        private void profile_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT u.FullName, u.Username, ISNULL(u.Gender,'') AS Gender, " +
                    "       ISNULL(u.Email,'') AS Email, ISNULL(u.Phone,'') AS Phone " +
                    "FROM Users u " +
                    "WHERE u.UserID = @id", DB.P("@id", Session.UserId));

                if (table.Rows.Count == 0) return;
                DataRow row = table.Rows[0];

                txtfullname.Text = row["FullName"].ToString();
                txtusername.Text = row["Username"].ToString();
                txtgender.Text = row["Gender"].ToString();
                txtemail.Text = row["Email"].ToString();
                txtphone.Text = row["Phone"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load profile: " + ex.Message, "My Profile",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtfullname.Text.Trim() == "")
            {
                MessageBox.Show("Full name cannot be empty.", "My Profile",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DB.Execute(
                    "UPDATE Users SET FullName = @name, Gender = @gender, Email = @email, " +
                    "Phone = @phone WHERE UserID = @id",
                    DB.P("@name", txtfullname.Text.Trim()),
                    DB.P("@gender", txtgender.Text.Trim()),
                    DB.P("@email", txtemail.Text.Trim()),
                    DB.P("@phone", txtphone.Text.Trim()),
                    DB.P("@id", Session.UserId));

                Session.FullName = txtfullname.Text.Trim();

                MessageBox.Show("Profile updated.", "My Profile",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "My Profile",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblfullname_Click(object sender, EventArgs e)
        {

        }
    }
}
