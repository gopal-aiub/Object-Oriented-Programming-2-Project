using System;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class Cart : Form
    {
        private DataTable cartTable;
        private bool saleSaved;
        private string invoiceNumber = "";
        private string paymentMethodName = "Cash";
        private string paymentDetails = "";

        private decimal subTotal, discountAmount, grandTotal;

        public Cart()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;

            this.btnsearch.Click += delegate { LoadProducts(textBox3.Text.Trim()); };
            this.btnshowall.Click += delegate { textBox3.Clear(); LoadProducts(""); };
            this.btnadd.Click += btnadd_Click;
            this.btnremoveitem.Click += btnremoveitem_Click;
            this.btnclearcart.Click += btnclearcart_Click;
            this.btnpay.Click += btnpay_Click;
            this.btninvoice.Click += btninvoice_Click;
            this.btnback.Click += delegate { this.Close(); };
            this.numericUpDown2.ValueChanged += delegate { Recalculate(); };
            this.dataGridView1.SelectionChanged += delegate { ResetQuantity(); };

            this.Load += Cart_Load;
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            this.Text = "Cart  |  Sales Executive : " + Session.FullName;
            BuildCartTable();
            LoadProducts("");
            Recalculate();
        }

        private void BuildCartTable()
        {
            cartTable = new DataTable();
            cartTable.Columns.Add("ProductID", typeof(int));
            cartTable.Columns.Add("Code", typeof(string));
            cartTable.Columns.Add("Product", typeof(string));
            cartTable.Columns.Add("Qty", typeof(int));
            cartTable.Columns.Add("Price", typeof(decimal));
            cartTable.Columns.Add("Total", typeof(decimal));

            dataGridView2.DataSource = cartTable;
            HideColumn(dataGridView2, "ProductID");
            MoneyColumn(dataGridView2, "Price");
            MoneyColumn(dataGridView2, "Total");
        }

        private void LoadProducts(string search)
        {
            try
            {
                string sql =
                    "SELECT ProductID, ProductCode AS Code, ProductName AS Product, " +
                    "       Price, StockQty AS Stock " +
                    "FROM Products " +
                    "WHERE IsActive = 1 AND (@s = '' OR ProductName LIKE '%' + @s + '%' " +
                    "      OR ProductCode LIKE '%' + @s + '%' OR Category LIKE '%' + @s + '%') " +
                    "ORDER BY ProductName";

                dataGridView1.DataSource = DB.GetTable(sql, DB.P("@s", search));

                HideColumn(dataGridView1, "ProductID");
                MoneyColumn(dataGridView1, "Price");

                ResetQuantity();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load products: " + ex.Message, "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResetQuantity()
        {
            numericUpDown1.Value = numericUpDown1.Minimum;
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (saleSaved) { AlreadySaved(); return; }

            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a product first.", "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int productId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ProductID"].Value);
            string code = dataGridView1.CurrentRow.Cells["Code"].Value.ToString();
            string name = dataGridView1.CurrentRow.Cells["Product"].Value.ToString();
            decimal price = Convert.ToDecimal(dataGridView1.CurrentRow.Cells["Price"].Value);
            int stock = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Stock"].Value);
            int qty = (int)numericUpDown1.Value;

            if (qty <= 0)
            {
                MessageBox.Show("Please enter a quantity of 1 or more.", "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRow found = null;
            foreach (DataRow row in cartTable.Rows)
            {
                if (Convert.ToInt32(row["ProductID"]) == productId) { found = row; break; }
            }

            int already = (found == null) ? 0 : Convert.ToInt32(found["Qty"]);

            if (already + qty > stock)
            {
                MessageBox.Show("Not enough stock.\n\nIn stock : " + stock +
                                "\nAlready in cart : " + already, "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (found == null)
            {
                DataRow row = cartTable.NewRow();
                row["ProductID"] = productId;
                row["Code"] = code;
                row["Product"] = name;
                row["Qty"] = qty;
                row["Price"] = price;
                row["Total"] = price * qty;
                cartTable.Rows.Add(row);
            }
            else
            {
                found["Qty"] = already + qty;
                found["Total"] = price * (already + qty);
            }

            ResetQuantity();
            Recalculate();
        }

        private void btnremoveitem_Click(object sender, EventArgs e)
        {
            if (saleSaved) { AlreadySaved(); return; }

            if (dataGridView2.CurrentRow == null)
            {
                MessageBox.Show("Please select a cart item first.", "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataRowView view = dataGridView2.CurrentRow.DataBoundItem as DataRowView;
            if (view != null)
            {
                view.Row.Delete();
                cartTable.AcceptChanges();
                Recalculate();
            }
        }

        private void btnclearcart_Click(object sender, EventArgs e)
        {
            if (saleSaved) { AlreadySaved(); return; }

            if (cartTable.Rows.Count == 0) return;

            if (MessageBox.Show("Remove all items from the cart?", "Cart",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                cartTable.Rows.Clear();
                Recalculate();
            }
        }

        private void Recalculate()
        {
            subTotal = 0;
            foreach (DataRow row in cartTable.Rows)
                subTotal += Convert.ToDecimal(row["Total"]);

            discountAmount = Math.Round(subTotal * numericUpDown2.Value / 100m, 2);
            grandTotal = subTotal - discountAmount;

            label1.Text = subTotal.ToString("N2");
            lbldis.Text = discountAmount.ToString("N2");
            lblgrand.Text = grandTotal.ToString("N2");
        }

        private void AlreadySaved()
        {
            MessageBox.Show("This sale is already saved (Invoice " + invoiceNumber + ").\n" +
                            "Close this window and start a new sale.", "Cart",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnpay_Click(object sender, EventArgs e)
        {
            if (saleSaved) { AlreadySaved(); return; }

            if (cartTable.Rows.Count == 0)
            {
                MessageBox.Show("The cart is empty.", "Payment",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (paymentMethod form = new paymentMethod())
            {
                if (form.ShowDialog() != DialogResult.OK) return;

                paymentMethodName = form.Method;
                paymentDetails = form.Info;
            }

            if (SaveSale())
            {
                MessageBox.Show("Payment received by " + paymentMethodName + ".\n" +
                                "Invoice No : " + invoiceNumber + "\n\n" +
                                "Sales history has been updated.", "Payment",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btninvoice_Click(object sender, EventArgs e)
        {
            if (cartTable.Rows.Count == 0)
            {
                MessageBox.Show("The cart is empty.", "Invoice",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!saleSaved)
            {
                if (!SaveSale()) return;
            }

            using (Invoice form = new Invoice(BuildInvoiceText()))
            {
                form.ShowDialog();
            }
        }

        private bool SaveSale()
        {
            if (saleSaved) return true;

            string customer = textBox1.Text.Trim();
            if (customer == "") customer = "Walk-in Customer";

            try
            {
                foreach (DataRow row in cartTable.Rows)
                {
                    int productId = Convert.ToInt32(row["ProductID"]);
                    int qty = Convert.ToInt32(row["Qty"]);

                    int stock = Convert.ToInt32(DB.Scalar(
                        "SELECT StockQty FROM Products WHERE ProductID = @pid", DB.P("@pid", productId)));

                    if (qty > stock)
                    {
                        MessageBox.Show("Not enough stock for '" + row["Product"] + "'.\n" +
                                        "In cart : " + qty + "    In stock : " + stock, "Cart",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                }

                int cartId = Convert.ToInt32(DB.Scalar(
                    "INSERT INTO Carts (CartCode, UserID, CustomerName, CustomerPhone, DiscountPercent, Status) " +
                    "VALUES ('TEMP', @uid, @name, @phone, @disc, 'Completed'); " +
                    "SELECT CAST(SCOPE_IDENTITY() AS INT);",
                    DB.P("@uid", Session.UserId),
                    DB.P("@name", customer),
                    DB.P("@phone", textBox2.Text.Trim()),
                    DB.P("@disc", numericUpDown2.Value)));

                DB.Execute("UPDATE Carts SET CartCode = @code WHERE CartID = @id",
                    DB.P("@code", "CART-" + cartId.ToString("D5")),
                    DB.P("@id", cartId));

                foreach (DataRow row in cartTable.Rows)
                {
                    DB.Execute(
                        "INSERT INTO CartItems (CartID, ProductID, Quantity, UnitPrice) " +
                        "VALUES (@cart, @pid, @qty, @price)",
                        DB.P("@cart", cartId),
                        DB.P("@pid", Convert.ToInt32(row["ProductID"])),
                        DB.P("@qty", Convert.ToInt32(row["Qty"])),
                        DB.P("@price", Convert.ToDecimal(row["Price"])));

                    DB.Execute("UPDATE Products SET StockQty = StockQty - @qty WHERE ProductID = @pid",
                        DB.P("@qty", Convert.ToInt32(row["Qty"])),
                        DB.P("@pid", Convert.ToInt32(row["ProductID"])));
                }

                int saleId = Convert.ToInt32(DB.Scalar(
                    "INSERT INTO Sales (InvoiceNo, CartID, UserID, CustomerName, " +
                    "SubTotal, DiscountAmount, TotalAmount, PaymentMethod, PaymentInfo) " +
                    "VALUES ('TEMP', @cart, @user, @customer, @sub, @disc, @total, @method, @info); " +
                    "SELECT CAST(SCOPE_IDENTITY() AS INT);",
                    DB.P("@cart", cartId),
                    DB.P("@user", Session.UserId),
                    DB.P("@customer", customer),
                    DB.P("@sub", subTotal),
                    DB.P("@disc", discountAmount),
                    DB.P("@total", grandTotal),
                    DB.P("@method", paymentMethodName),
                    DB.P("@info", paymentDetails)));

                invoiceNumber = "INV-" + DateTime.Now.ToString("yyyyMMdd") + "-" + saleId.ToString("D4");

                DB.Execute("UPDATE Sales SET InvoiceNo = @inv WHERE SaleID = @id",
                    DB.P("@inv", invoiceNumber),
                    DB.P("@id", saleId));

                saleSaved = true;
                LoadProducts(textBox3.Text.Trim());

                AppEvents.RaiseSaleSaved();

                CheckLowStock(cartId);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving the sale: " + ex.Message, "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void CheckLowStock(int cartId)
        {
            try
            {
                DataTable low = DB.GetTable(
                    "SELECT DISTINCT p.ProductID, p.ProductName, p.StockQty, p.ReorderLevel " +
                    "FROM Products p INNER JOIN CartItems ci ON ci.ProductID = p.ProductID " +
                    "WHERE ci.CartID = @cart AND p.StockQty <= p.ReorderLevel",
                    DB.P("@cart", cartId));

                if (low.Rows.Count == 0) return;

                string list = "";
                foreach (DataRow row in low.Rows)
                    list += "- " + row["ProductName"] + "  (stock " + row["StockQty"] + ")\n";

                if (MessageBox.Show("These products are now in LOW STOCK:\n\n" + list +
                        "\nSend a notification to the manager?", "Low Stock",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

                foreach (DataRow row in low.Rows)
                {
                    DB.Execute(
                        "INSERT INTO Notifications (ProductID, Message, CreatedBy) VALUES (@pid, @msg, @by)",
                        DB.P("@pid", Convert.ToInt32(row["ProductID"])),
                        DB.P("@msg", "LOW STOCK: " + row["ProductName"] + " has only " +
                                     row["StockQty"] + " left. Reported by " + Session.FullName + "."),
                        DB.P("@by", Session.UserId));
                }

                MessageBox.Show("Manager notified.", "Low Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Notification error: " + ex.Message, "Low Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string BuildInvoiceText()
        {
            StringBuilder text = new StringBuilder();

            text.AppendLine("               SUPER SHOP - SALES INVOICE");
            text.AppendLine("=============================================================");
            text.AppendLine("Invoice No : " + invoiceNumber);
            text.AppendLine("Date       : " + DateTime.Now.ToString("dd-MMM-yyyy  hh:mm tt"));
            text.AppendLine("Customer   : " + (textBox1.Text.Trim() == "" ? "Walk-in Customer" : textBox1.Text.Trim())
                                            + "   " + textBox2.Text.Trim());
            text.AppendLine("Served by  : " + Session.FullName);
            text.AppendLine("Payment    : " + paymentMethodName +
                            (paymentDetails == "" ? "" : "   (" + paymentDetails + ")"));
            text.AppendLine("=============================================================");
            text.AppendLine("Product                        Qty      Price       Total");
            text.AppendLine("-------------------------------------------------------------");

            foreach (DataRow row in cartTable.Rows)
            {
                string name = row["Product"].ToString();
                if (name.Length > 28) name = name.Substring(0, 28);

                text.AppendLine(
                    name.PadRight(30) +
                    Convert.ToInt32(row["Qty"]).ToString().PadLeft(3) + "  " +
                    Convert.ToDecimal(row["Price"]).ToString("N2").PadLeft(9) + "  " +
                    Convert.ToDecimal(row["Total"]).ToString("N2").PadLeft(11));
            }

            text.AppendLine("-------------------------------------------------------------");
            text.AppendLine("Sub Total".PadRight(44) + subTotal.ToString("N2").PadLeft(17));
            text.AppendLine(("Discount (" + numericUpDown2.Value.ToString("N2") + "%)").PadRight(44) +
                            discountAmount.ToString("N2").PadLeft(17));
            text.AppendLine("GRAND TOTAL".PadRight(44) + grandTotal.ToString("N2").PadLeft(17));
            text.AppendLine("=============================================================");
            text.AppendLine();
            text.AppendLine("            Thank you for shopping with us!");

            return text.ToString();
        }

        private void lblsb_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void lblcartitem_Click(object sender, EventArgs e)
        {
        }

        private static void HideColumn(DataGridView grid, string columnName)
        {
            if (grid.Columns.Contains(columnName)) grid.Columns[columnName].Visible = false;
        }

        private static void MoneyColumn(DataGridView grid, string columnName)
        {
            if (grid.Columns.Contains(columnName))
                grid.Columns[columnName].DefaultCellStyle.Format = "N2";
        }
    }
}
