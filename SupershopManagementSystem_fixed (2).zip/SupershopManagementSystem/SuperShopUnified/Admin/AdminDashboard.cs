using System.Windows.Forms;

namespace SuperShopUnified
{
    public partial class AdminDashboard : Form
    {

        public Login CallerLogin { get; set; }

        public AdminDashboard()
        {
            InitializeComponent();
            this.Text = "Admin Dashboard - Welcome, " + Session.FullName;
            this.button1.Click += button1_Click;
            this.button3.Click += button3_Click;
            this.btnLogout.Click += btnLogout_Click;
        }

        private void button2_Click(object sender, System.EventArgs e)
        {

            using (AdminStockManage form = new AdminStockManage()) { form.ShowDialog(); }
        }

        private void btnLogout_Click(object sender, System.EventArgs e)
        {
            if (MessageBox.Show("Do you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            Session.Clear();

            if (CallerLogin != null)
                CallerLogin.ShowLoginAgain();
            else
                new Login().Show();

            this.Close();
        }

        private void btnemployees_Click(object sender, System.EventArgs e)
        {
            Employees emp = new Employees();
            emp.Show();
        }

        private void button3_Click(object sender, System.EventArgs e)
        {

            using (NotificationsForm form = new NotificationsForm()) { form.ShowDialog(); }
        }

        private void button1_Click(object sender, System.EventArgs e)
        {

            using (ManagerSalesHistoryForm form = new ManagerSalesHistoryForm(0, "All Sales")) { form.ShowDialog(); }
        }
    }
}
