using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public partial class AdminStockManage : Form
    {

        private const string ConnStr =
            @"Data Source=ETI\SQLEXPRESS;Initial Catalog=SuperShop1;Integrated Security=True;TrustServerCertificate=True;";

        private int selectedProductId = 0;

        public AdminStockManage()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.CenterParent;

            this.btnAdd.Click += btnAdd_Click;
            this.btnUpdate.Click += btnUpdate_Click;
            this.btnDelete.Click += btnDelete_Click;
            this.btnClear.Click += delegate { ClearFields(); };
            this.btnSearch.Click += delegate { LoadStock(txtSearch.Text.Trim()); };
            this.btnShowAll.Click += delegate { txtSearch.Clear(); LoadStock(""); };
            this.btnBack.Click += delegate { this.Close(); };
            this.dataGridView1.CellClick += dataGridView1_CellClick;
            this.Load += delegate { LoadStock(""); };
        }

        private void LoadStock(string search)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();

                    string query =
                        "SELECT ProductID, ProductCode AS Code, ProductName AS Product, Category, " +
                        "       Price, StockQty AS Stock, ReorderLevel AS [Low Limit] " +
                        "FROM Products " +
                        "WHERE IsActive = 1 AND (@s = '' OR ProductName LIKE '%' + @s + '%' " +
                        "      OR ProductCode LIKE '%' + @s + '%' OR Category LIKE '%' + @s + '%') " +
                        "ORDER BY ProductID";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@s", search ?? "");

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            dataGridView1.DataSource = table;
                        }
                    }
                }

                if (dataGridView1.Columns.Contains("ProductID"))
                    dataGridView1.Columns["ProductID"].Visible = false;
                if (dataGridView1.Columns.Contains("Price"))
                    dataGridView1.Columns["Price"].DefaultCellStyle.Format = "N2";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot load stock: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                selectedProductId = Convert.ToInt32(row.Cells["ProductID"].Value);
                txtCode.Text = row.Cells["Code"].Value?.ToString() ?? "";
                txtName.Text = row.Cells["Product"].Value?.ToString() ?? "";
                txtCategory.Text = row.Cells["Category"].Value?.ToString() ?? "";
                txtPrice.Text = row.Cells["Price"].Value?.ToString() ?? "";
                txtQty.Text = row.Cells["Stock"].Value?.ToString() ?? "";
                txtReorder.Text = row.Cells["Low Limit"].Value?.ToString() ?? "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error selecting row: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateFields(out decimal price, out int qty, out int reorder)
        {
            price = 0; qty = 0; reorder = 0;

            if (txtCode.Text.Trim() == "" || txtName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter Code and Product Name.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtPrice.Text.Trim(), out price))
            {
                MessageBox.Show("Price must be a number.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtQty.Text.Trim(), out qty))
            {
                MessageBox.Show("Stock quantity must be a whole number.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtReorder.Text.Trim(), out reorder))
            {
                MessageBox.Show("Low Limit must be a whole number.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            decimal price; int qty, reorder;
            if (!ValidateFields(out price, out qty, out reorder)) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Products WHERE ProductCode = @code";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@code", txtCode.Text.Trim());
                        int exists = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (exists > 0)
                        {
                            MessageBox.Show("A product with this Code already exists! Use Update instead.",
                                "Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string insertQuery =
                        "INSERT INTO Products (ProductCode, ProductName, Category, Price, StockQty, ReorderLevel, IsActive) " +
                        "VALUES (@code, @name, @category, @price, @qty, @reorder, 1)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@code", txtCode.Text.Trim());
                        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@category", txtCategory.Text.Trim());
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@reorder", reorder);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show("Product added successfully! It will now show up in every Stock/Cart screen.",
                                "Stock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                            LoadStock(txtSearch.Text.Trim());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Please select a product from the table first.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            decimal price; int qty, reorder;
            if (!ValidateFields(out price, out qty, out reorder)) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();

                    string updateQuery =
                        "UPDATE Products SET ProductCode=@code, ProductName=@name, Category=@category, " +
                        "Price=@price, StockQty=@qty, ReorderLevel=@reorder WHERE ProductID=@id";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@code", txtCode.Text.Trim());
                        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@category", txtCategory.Text.Trim());
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@reorder", reorder);
                        cmd.Parameters.AddWithValue("@id", selectedProductId);

                        int rows = cmd.ExecuteNonQuery();

                        MessageBox.Show(rows > 0
                                ? "Product updated successfully! The new price/stock will show up everywhere immediately."
                                : "Update failed. No matching product found.",
                            "Stock", MessageBoxButtons.OK,
                            rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                        ClearFields();
                        LoadStock(txtSearch.Text.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Please select a product from the table first.", "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Remove '" + txtName.Text + "' from stock?\n\n" +
                    "It will disappear from Stock and from the Sales Executive's Cart right away.",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();

                    string deleteQuery = "UPDATE Products SET IsActive = 0 WHERE ProductID = @id";

                    using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", selectedProductId);
                        int rows = cmd.ExecuteNonQuery();

                        MessageBox.Show(rows > 0 ? "Product removed from stock." : "Delete failed. No matching product found.",
                            "Stock", MessageBoxButtons.OK,
                            rows > 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                        ClearFields();
                        LoadStock(txtSearch.Text.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFields()
        {
            selectedProductId = 0;
            txtCode.Text = "";
            txtName.Text = "";
            txtCategory.Text = "";
            txtPrice.Text = "";
            txtQty.Text = "";
            txtReorder.Text = "";
        }
    }
}
