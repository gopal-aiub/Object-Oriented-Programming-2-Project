using System;
using System.Data;
using System.Windows.Forms;

namespace SuperShopUnified
{

    public partial class Employees : Form
    {
        public Employees()
        {
            InitializeComponent();
            this.btnback.Click += delegate { this.Close(); };
        }

        private void Employees_Load(object sender, EventArgs e)
        {
            LoadData();
            txtuserid.ReadOnly = true;
        }

        private void LoadData()
        {
            try
            {
                DataTable table = DB.GetTable(
                    "SELECT UserID AS userID, Email AS email, PasswordHash AS pass, " +
                    "       ISNULL(Gender,'') AS gender, ISNULL(Phone,'') AS phoneNo, " +
                    "       Username AS username, Role AS role " +
                    "FROM Users ORDER BY UserID");

                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
        }

        private void btnenter_Click(object sender, EventArgs e)
        {
            if (txtemail.Text.Trim() == "" || txtpassword.Text.Trim() == "" ||
                txtusername.Text.Trim() == "")
            {
                MessageBox.Show("Please fill Email, Password and User Name!");
                return;
            }

            if (txtrole.SelectedItem == null)
            {
                MessageBox.Show("Please select a Role (Admin / Manager / SalesExecutive)!");
                return;
            }

            string role = txtrole.SelectedItem.ToString();

            try
            {
                object exists = DB.Scalar("SELECT COUNT(*) FROM Users WHERE Email = @email",
                    DB.P("@email", txtemail.Text.Trim()));

                if (Convert.ToInt32(exists) > 0)
                {
                    MessageBox.Show("This Email already exists!");
                    return;
                }

                object usernameExists = DB.Scalar("SELECT COUNT(*) FROM Users WHERE Username = @username",
                    DB.P("@username", txtusername.Text.Trim()));

                if (Convert.ToInt32(usernameExists) > 0)
                {
                    MessageBox.Show("This User Name already exists! Please choose a different one.");
                    return;
                }

                DB.Execute(
                    "INSERT INTO Users (FullName, Username, Email, PasswordHash, Gender, Phone, Role, IsActive) " +
                    "VALUES (@fullname, @username, @email, @pass, @gender, @phoneNo, @role, 1)",
                    DB.P("@fullname", txtusername.Text.Trim()),
                    DB.P("@username", txtusername.Text.Trim()),
                    DB.P("@email", txtemail.Text.Trim()),
                    DB.P("@pass", Security.Hash(txtpassword.Text.Trim())),
                    DB.P("@gender", txtgender.Text.Trim()),
                    DB.P("@phoneNo", txtphone.Text.Trim()),
                    DB.P("@role", role));

                MessageBox.Show("Employee Added Successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message +
                    "\n\nIf this mentions CK_Users_Role, please pick Role from the dropdown " +
                    "(don't type it) - the database only accepts Admin, Manager or SalesExecutive exactly.");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            try
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtuserid.Text = row.Cells["userID"].Value?.ToString() ?? "";
                txtemail.Text = row.Cells["email"].Value?.ToString() ?? "";
                txtpassword.Text = "";
                txtgender.Text = row.Cells["gender"].Value?.ToString() ?? "";
                txtphone.Text = row.Cells["phoneNo"].Value?.ToString() ?? "";
                txtusername.Text = row.Cells["username"].Value?.ToString() ?? "";

                string roleFromGrid = row.Cells["role"].Value?.ToString() ?? "";
                if (txtrole.Items.Contains(roleFromGrid))
                    txtrole.SelectedItem = roleFromGrid;
                else
                    txtrole.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error selecting row: " + ex.Message);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtuserid.Text.Trim() == "")
            {
                MessageBox.Show("Please select a record from the table first!");
                return;
            }

            if (txtrole.SelectedItem == null)
            {
                MessageBox.Show("Please select a Role (Admin / Manager / SalesExecutive)!");
                return;
            }

            try
            {
                string role = txtrole.SelectedItem.ToString();

                if (txtpassword.Text.Trim() == "")
                {
                    DB.Execute(
                        "UPDATE Users SET Email=@email, Gender=@gender, Phone=@phoneNo, " +
                        "Username=@username, Role=@role WHERE UserID=@userid",
                        DB.P("@email", txtemail.Text.Trim()),
                        DB.P("@gender", txtgender.Text.Trim()),
                        DB.P("@phoneNo", txtphone.Text.Trim()),
                        DB.P("@username", txtusername.Text.Trim()),
                        DB.P("@role", role),
                        DB.P("@userid", Convert.ToInt32(txtuserid.Text.Trim())));
                }
                else
                {
                    DB.Execute(
                        "UPDATE Users SET Email=@email, PasswordHash=@pass, Gender=@gender, " +
                        "Phone=@phoneNo, Username=@username, Role=@role WHERE UserID=@userid",
                        DB.P("@email", txtemail.Text.Trim()),
                        DB.P("@pass", Security.Hash(txtpassword.Text.Trim())),
                        DB.P("@gender", txtgender.Text.Trim()),
                        DB.P("@phoneNo", txtphone.Text.Trim()),
                        DB.P("@username", txtusername.Text.Trim()),
                        DB.P("@role", role),
                        DB.P("@userid", Convert.ToInt32(txtuserid.Text.Trim())));
                }

                MessageBox.Show("Employee Updated Successfully!");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtuserid.Text.Trim() == "")
            {
                MessageBox.Show("Please select a record from the table first!");
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this employee?",
                "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.No) return;

            try
            {
                int rows = DB.Execute("DELETE FROM Users WHERE UserID=@userid",
                    DB.P("@userid", Convert.ToInt32(txtuserid.Text.Trim())));

                MessageBox.Show(rows > 0 ? "Employee Deleted Successfully!" : "Delete Failed! No matching record found.");
                ClearFields();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
        }

        private void btnclean_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txtuserid.Text = "";
            txtemail.Text = "";
            txtpassword.Text = "";
            txtgender.Text = "";
            txtphone.Text = "";
            txtusername.Text = "";
            txtrole.SelectedIndex = -1;
        }
    }
}
