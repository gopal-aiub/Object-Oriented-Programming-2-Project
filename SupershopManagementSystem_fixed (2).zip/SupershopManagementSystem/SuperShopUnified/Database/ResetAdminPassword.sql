-- ============================================================
-- Use this ONLY if you already created the SuperShop1 database
-- earlier and don't want to lose your existing data by rerunning
-- the full CreateDatabase.sql (which drops and recreates tables).
--
-- This just resets the password for the 3 default accounts to: admin123
-- ============================================================

USE SuperShop1;
GO

UPDATE dbo.Users
SET PasswordHash = '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'
WHERE Email IN (N'admin@shop.com', N'manager@shop.com', N'executive@shop.com');
GO

PRINT 'Passwords reset. Login with admin@shop.com / manager@shop.com / executive@shop.com using password: admin123';
