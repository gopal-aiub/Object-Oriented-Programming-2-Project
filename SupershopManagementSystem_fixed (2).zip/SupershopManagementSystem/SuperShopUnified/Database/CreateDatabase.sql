
IF DB_ID('SuperShop1') IS NULL
BEGIN
    CREATE DATABASE SuperShop1;
END
GO

USE SuperShop1;
GO

IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
GO
CREATE TABLE dbo.Users
(
    UserID          INT IDENTITY(1,1) PRIMARY KEY,
    FullName        NVARCHAR(100)   NOT NULL,
    Username        NVARCHAR(50)    NOT NULL UNIQUE,
    Email           NVARCHAR(100)   NOT NULL UNIQUE,
    PasswordHash    NVARCHAR(200)   NOT NULL,
    Gender          NVARCHAR(10)    NULL,
    Phone           NVARCHAR(20)    NULL,
    Role            NVARCHAR(20)    NOT NULL,
    IsActive        BIT             NOT NULL DEFAULT 1,
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),
    CONSTRAINT CK_Users_Role CHECK (Role IN ('Admin','Manager','SalesExecutive'))
);
GO

IF OBJECT_ID('dbo.Products', 'U') IS NOT NULL DROP TABLE dbo.Products;
GO
CREATE TABLE dbo.Products
(
    ProductID       INT IDENTITY(1,1) PRIMARY KEY,
    ProductCode     NVARCHAR(30)    NOT NULL UNIQUE,
    ProductName     NVARCHAR(100)   NOT NULL,
    Category        NVARCHAR(50)    NULL,
    Price           DECIMAL(10,2)   NOT NULL DEFAULT 0,
    StockQty        INT             NOT NULL DEFAULT 0,
    ReorderLevel    INT             NOT NULL DEFAULT 5,
    IsActive        BIT             NOT NULL DEFAULT 1
);
GO

IF OBJECT_ID('dbo.CartItems', 'U') IS NOT NULL DROP TABLE dbo.CartItems;
IF OBJECT_ID('dbo.Carts', 'U') IS NOT NULL DROP TABLE dbo.Carts;
GO
CREATE TABLE dbo.Carts
(
    CartID          INT IDENTITY(1,1) PRIMARY KEY,
    CartCode        NVARCHAR(20)    NOT NULL,
    UserID          INT             NOT NULL REFERENCES dbo.Users(UserID),
    CustomerName    NVARCHAR(100)   NULL,
    CustomerPhone   NVARCHAR(20)    NULL,
    DiscountPercent DECIMAL(5,2)    NOT NULL DEFAULT 0,
    Status          NVARCHAR(20)    NOT NULL DEFAULT 'Completed',
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE()
);
GO
CREATE TABLE dbo.CartItems
(
    CartItemID      INT IDENTITY(1,1) PRIMARY KEY,
    CartID          INT             NOT NULL REFERENCES dbo.Carts(CartID),
    ProductID       INT             NOT NULL REFERENCES dbo.Products(ProductID),
    Quantity        INT             NOT NULL,
    UnitPrice       DECIMAL(10,2)   NOT NULL
);
GO

IF OBJECT_ID('dbo.Sales', 'U') IS NOT NULL DROP TABLE dbo.Sales;
GO
CREATE TABLE dbo.Sales
(
    SaleID          INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceNo       NVARCHAR(30)    NOT NULL,
    CartID          INT             NOT NULL REFERENCES dbo.Carts(CartID),
    UserID          INT             NOT NULL REFERENCES dbo.Users(UserID),
    CustomerName    NVARCHAR(100)   NULL,
    SubTotal        DECIMAL(10,2)   NOT NULL DEFAULT 0,
    DiscountAmount  DECIMAL(10,2)   NOT NULL DEFAULT 0,
    TotalAmount     DECIMAL(10,2)   NOT NULL DEFAULT 0,
    PaymentMethod   NVARCHAR(30)    NULL,
    PaymentInfo     NVARCHAR(200)   NULL,
    SaleDate        DATETIME        NOT NULL DEFAULT GETDATE()
);
GO

IF OBJECT_ID('dbo.Notifications', 'U') IS NOT NULL DROP TABLE dbo.Notifications;
GO
CREATE TABLE dbo.Notifications
(
    NotificationID  INT IDENTITY(1,1) PRIMARY KEY,
    ProductID       INT             NULL REFERENCES dbo.Products(ProductID),
    Message         NVARCHAR(400)   NOT NULL,
    CreatedBy       INT             NOT NULL REFERENCES dbo.Users(UserID),
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),
    IsRead          BIT             NOT NULL DEFAULT 0
);
GO

-- This is the SHA-256 hash of the password: admin123
-- (Use this same password for all three seeded accounts below; change it
--  after first login from the "Forgot Password" screen if you want.)
DECLARE @DefaultPasswordHash NVARCHAR(200) = '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9';

INSERT INTO dbo.Users (FullName, Username, Email, PasswordHash, Gender, Phone, Role, IsActive)
VALUES
    (N'Shop Admin',      N'admin',      N'admin@shop.com',      @DefaultPasswordHash, N'M', N'01700000001', N'Admin',          1),
    (N'Shop Manager',    N'manager',    N'manager@shop.com',    @DefaultPasswordHash, N'M', N'01700000002', N'Manager',        1),
    (N'Sales Executive', N'executive',  N'executive@shop.com',  @DefaultPasswordHash, N'F', N'01700000003', N'SalesExecutive', 1);
GO

INSERT INTO dbo.Products (ProductCode, ProductName, Category, Price, StockQty, ReorderLevel, IsActive) VALUES
    (N'P001', N'Rice (5kg)',        N'Grocery',    650.00, 40, 10, 1),
    (N'P002', N'Cooking Oil (1L)',  N'Grocery',    210.00, 25, 8,  1),
    (N'P003', N'Toothpaste',        N'Toiletries', 90.00,  3,  10, 1),
    (N'P004', N'Notebook',          N'Stationery', 40.00,  60, 15, 1);
GO

PRINT 'SuperShop1 created and seeded successfully.';
