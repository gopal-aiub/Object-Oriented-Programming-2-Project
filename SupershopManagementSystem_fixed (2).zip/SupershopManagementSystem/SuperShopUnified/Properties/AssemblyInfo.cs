using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperShopUnified")]
[assembly: AssemblyDescription("Super Shop Management System - Admin, Manager and Sales Executive in one application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SuperShopUnified")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("2f2b6a5a-6a3a-4b8e-9a2b-9a1f2a3b4c5d")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
