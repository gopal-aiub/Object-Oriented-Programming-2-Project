﻿namespace registration_form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblemail = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.lbldegree = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lbldept = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.btnsignup = new System.Windows.Forms.Button();
            this.dtpdob = new System.Windows.Forms.DateTimePicker();
            this.rdmale = new System.Windows.Forms.RadioButton();
            this.rdfemale = new System.Windows.Forms.RadioButton();
            this.cbdept = new System.Windows.Forms.ComboBox();
            this.cbcse = new System.Windows.Forms.CheckBox();
            this.cbeee = new System.Windows.Forms.CheckBox();
            this.cbenglish = new System.Windows.Forms.CheckBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblerrorname = new System.Windows.Forms.Label();
            this.lblerroremail = new System.Windows.Forms.Label();
            this.lblerrorpass = new System.Windows.Forms.Label();
            this.lblerrordob = new System.Windows.Forms.Label();
            this.lblerrorgender = new System.Windows.Forms.Label();
            this.lblerrorblood = new System.Windows.Forms.Label();
            this.lblerrordegree = new System.Windows.Forms.Label();
            this.lblerrordept = new System.Windows.Forms.Label();
            this.lblerroraddress = new System.Windows.Forms.Label();
            this.lblregistration = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(256, 125);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(52, 20);
            this.lblemail.TabIndex = 0;
            this.lblemail.Text = "Email:";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(256, 86);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(55, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "Name:";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(219, 165);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(90, 20);
            this.lblpass.TabIndex = 2;
            this.lblpass.Text = "Passsword:";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(338, 82);
            this.txtname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(180, 26);
            this.txtname.TabIndex = 3;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(338, 121);
            this.txtemail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(180, 26);
            this.txtemail.TabIndex = 4;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(338, 165);
            this.txtpass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtpass.Name = "txtpass";
            this.txtpass.PasswordChar = '$';
            this.txtpass.Size = new System.Drawing.Size(180, 26);
            this.txtpass.TabIndex = 5;
            // 
            // lbldegree
            // 
            this.lbldegree.AutoSize = true;
            this.lbldegree.Location = new System.Drawing.Point(237, 322);
            this.lbldegree.Name = "lbldegree";
            this.lbldegree.Size = new System.Drawing.Size(66, 20);
            this.lbldegree.TabIndex = 6;
            this.lbldegree.Text = "Degree:";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(238, 270);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(67, 20);
            this.lblgender.TabIndex = 7;
            this.lblgender.Text = "Gender:";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Location = new System.Drawing.Point(256, 211);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(48, 20);
            this.lbldob.TabIndex = 8;
            this.lbldob.Text = "DOB:";
            // 
            // lbldept
            // 
            this.lbldept.AutoSize = true;
            this.lbldept.Location = new System.Drawing.Point(210, 386);
            this.lbldept.Name = "lbldept";
            this.lbldept.Size = new System.Drawing.Size(98, 20);
            this.lbldept.TabIndex = 9;
            this.lbldept.Text = "Department:";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(219, 480);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(72, 20);
            this.lbladdress.TabIndex = 11;
            this.lbladdress.Text = "Address:";
            // 
            // btnsignup
            // 
            this.btnsignup.Location = new System.Drawing.Point(390, 596);
            this.btnsignup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnsignup.Name = "btnsignup";
            this.btnsignup.Size = new System.Drawing.Size(84, 41);
            this.btnsignup.TabIndex = 12;
            this.btnsignup.Text = "Sign UP";
            this.btnsignup.UseVisualStyleBackColor = true;
            this.btnsignup.Click += new System.EventHandler(this.btnsignup_Click);
            // 
            // dtpdob
            // 
            this.dtpdob.Location = new System.Drawing.Point(338, 211);
            this.dtpdob.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpdob.Name = "dtpdob";
            this.dtpdob.Size = new System.Drawing.Size(224, 26);
            this.dtpdob.TabIndex = 13;
            // 
            // rdmale
            // 
            this.rdmale.AutoSize = true;
            this.rdmale.Location = new System.Drawing.Point(338, 270);
            this.rdmale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdmale.Name = "rdmale";
            this.rdmale.Size = new System.Drawing.Size(72, 24);
            this.rdmale.TabIndex = 14;
            this.rdmale.TabStop = true;
            this.rdmale.Text = "Male ";
            this.rdmale.UseVisualStyleBackColor = true;
            // 
            // rdfemale
            // 
            this.rdfemale.AutoSize = true;
            this.rdfemale.Location = new System.Drawing.Point(431, 270);
            this.rdfemale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdfemale.Name = "rdfemale";
            this.rdfemale.Size = new System.Drawing.Size(91, 24);
            this.rdfemale.TabIndex = 15;
            this.rdfemale.TabStop = true;
            this.rdfemale.Text = "Female ";
            this.rdfemale.UseVisualStyleBackColor = true;
            // 
            // cbdept
            // 
            this.cbdept.FormattingEnabled = true;
            this.cbdept.Items.AddRange(new object[] {
            "Fst ",
            "FE",
            "FBA"});
            this.cbdept.Location = new System.Drawing.Point(338, 382);
            this.cbdept.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbdept.Name = "cbdept";
            this.cbdept.Size = new System.Drawing.Size(136, 28);
            this.cbdept.TabIndex = 20;
            this.cbdept.SelectedIndexChanged += new System.EventHandler(this.cbdept_SelectedIndexChanged);
            // 
            // cbcse
            // 
            this.cbcse.AutoSize = true;
            this.cbcse.Location = new System.Drawing.Point(338, 322);
            this.cbcse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbcse.Name = "cbcse";
            this.cbcse.Size = new System.Drawing.Size(68, 24);
            this.cbcse.TabIndex = 21;
            this.cbcse.Text = "CSE";
            this.cbcse.UseVisualStyleBackColor = true;
            // 
            // cbeee
            // 
            this.cbeee.AutoSize = true;
            this.cbeee.Location = new System.Drawing.Point(447, 322);
            this.cbeee.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbeee.Name = "cbeee";
            this.cbeee.Size = new System.Drawing.Size(68, 24);
            this.cbeee.TabIndex = 22;
            this.cbeee.Text = "EEE";
            this.cbeee.UseVisualStyleBackColor = true;
            // 
            // cbenglish
            // 
            this.cbenglish.AutoSize = true;
            this.cbenglish.Location = new System.Drawing.Point(565, 322);
            this.cbenglish.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbenglish.Name = "cbenglish";
            this.cbenglish.Size = new System.Drawing.Size(87, 24);
            this.cbenglish.TabIndex = 23;
            this.cbenglish.Text = "English";
            this.cbenglish.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(338, 440);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(242, 119);
            this.richTextBox1.TabIndex = 24;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // lblerrorname
            // 
            this.lblerrorname.AutoSize = true;
            this.lblerrorname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblerrorname.ForeColor = System.Drawing.Color.IndianRed;
            this.lblerrorname.Location = new System.Drawing.Point(482, 86);
            this.lblerrorname.Name = "lblerrorname";
            this.lblerrorname.Size = new System.Drawing.Size(0, 25);
            this.lblerrorname.TabIndex = 25;
            // 
            // lblerroremail
            // 
            this.lblerroremail.AutoSize = true;
            this.lblerroremail.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerroremail.Location = new System.Drawing.Point(482, 129);
            this.lblerroremail.Name = "lblerroremail";
            this.lblerroremail.Size = new System.Drawing.Size(0, 20);
            this.lblerroremail.TabIndex = 26;
            // 
            // lblerrorpass
            // 
            this.lblerrorpass.AutoSize = true;
            this.lblerrorpass.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerrorpass.Location = new System.Drawing.Point(482, 169);
            this.lblerrorpass.Name = "lblerrorpass";
            this.lblerrorpass.Size = new System.Drawing.Size(0, 20);
            this.lblerrorpass.TabIndex = 27;
            // 
            // lblerrordob
            // 
            this.lblerrordob.AutoSize = true;
            this.lblerrordob.Location = new System.Drawing.Point(503, 204);
            this.lblerrordob.Name = "lblerrordob";
            this.lblerrordob.Size = new System.Drawing.Size(0, 20);
            this.lblerrordob.TabIndex = 28;
            // 
            // lblerrorgender
            // 
            this.lblerrorgender.AutoSize = true;
            this.lblerrorgender.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerrorgender.Location = new System.Drawing.Point(518, 246);
            this.lblerrorgender.Name = "lblerrorgender";
            this.lblerrorgender.Size = new System.Drawing.Size(0, 20);
            this.lblerrorgender.TabIndex = 29;
            // 
            // lblerrorblood
            // 
            this.lblerrorblood.AutoSize = true;
            this.lblerrorblood.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerrorblood.Location = new System.Drawing.Point(668, 322);
            this.lblerrorblood.Name = "lblerrorblood";
            this.lblerrorblood.Size = new System.Drawing.Size(0, 20);
            this.lblerrorblood.TabIndex = 30;
            // 
            // lblerrordegree
            // 
            this.lblerrordegree.AutoSize = true;
            this.lblerrordegree.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerrordegree.Location = new System.Drawing.Point(641, 386);
            this.lblerrordegree.Name = "lblerrordegree";
            this.lblerrordegree.Size = new System.Drawing.Size(0, 20);
            this.lblerrordegree.TabIndex = 31;
            // 
            // lblerrordept
            // 
            this.lblerrordept.AutoSize = true;
            this.lblerrordept.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerrordept.Location = new System.Drawing.Point(443, 449);
            this.lblerrordept.Name = "lblerrordept";
            this.lblerrordept.Size = new System.Drawing.Size(0, 20);
            this.lblerrordept.TabIndex = 32;
            // 
            // lblerroraddress
            // 
            this.lblerroraddress.AutoSize = true;
            this.lblerroraddress.ForeColor = System.Drawing.Color.Firebrick;
            this.lblerroraddress.Location = new System.Drawing.Point(561, 540);
            this.lblerroraddress.Name = "lblerroraddress";
            this.lblerroraddress.Size = new System.Drawing.Size(0, 20);
            this.lblerroraddress.TabIndex = 33;
            // 
            // lblregistration
            // 
            this.lblregistration.AutoSize = true;
            this.lblregistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblregistration.Location = new System.Drawing.Point(317, 20);
            this.lblregistration.Name = "lblregistration";
            this.lblregistration.Size = new System.Drawing.Size(205, 29);
            this.lblregistration.TabIndex = 34;
            this.lblregistration.Text = "REGISTRATION";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(900, 730);
            this.Controls.Add(this.lblregistration);
            this.Controls.Add(this.lblerroraddress);
            this.Controls.Add(this.lblerrordept);
            this.Controls.Add(this.lblerrordegree);
            this.Controls.Add(this.lblerrorblood);
            this.Controls.Add(this.lblerrorgender);
            this.Controls.Add(this.lblerrordob);
            this.Controls.Add(this.lblerrorpass);
            this.Controls.Add(this.lblerroremail);
            this.Controls.Add(this.lblerrorname);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.cbenglish);
            this.Controls.Add(this.cbeee);
            this.Controls.Add(this.cbcse);
            this.Controls.Add(this.cbdept);
            this.Controls.Add(this.rdfemale);
            this.Controls.Add(this.rdmale);
            this.Controls.Add(this.dtpdob);
            this.Controls.Add(this.btnsignup);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lbldept);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.lbldegree);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblemail);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Label lbldegree;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lbldept;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Button btnsignup;
        private System.Windows.Forms.DateTimePicker dtpdob;
        private System.Windows.Forms.RadioButton rdmale;
        private System.Windows.Forms.RadioButton rdfemale;
        private System.Windows.Forms.ComboBox cbdept;
        private System.Windows.Forms.CheckBox cbcse;
        private System.Windows.Forms.CheckBox cbeee;
        private System.Windows.Forms.CheckBox cbenglish;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblerrorname;
        private System.Windows.Forms.Label lblerroremail;
        private System.Windows.Forms.Label lblerrorpass;
        private System.Windows.Forms.Label lblerrordob;
        private System.Windows.Forms.Label lblerrorgender;
        private System.Windows.Forms.Label lblerrorblood;
        private System.Windows.Forms.Label lblerrordegree;
        private System.Windows.Forms.Label lblerrordept;
        private System.Windows.Forms.Label lblerroraddress;
        private System.Windows.Forms.Label lblregistration;
    }
}

