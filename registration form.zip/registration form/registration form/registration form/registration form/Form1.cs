﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace registration_form
{
    public partial class Form1 : Form
    {
        string name, Email, pass, gender, blood, degree, dept, address;

        private void cbdept_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        DateTime dob;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void InsertIntoTable(string tablename)
        {
            using (SqlConnection conn = new SqlConnection(
                @"Data Source=ETI\SQLEXPRESS;Initial Catalog=Test;Integrated Security=True;"))
            {
                conn.Open();

                string query = "INSERT INTO " + tablename +
                               " (Name, Email, Password, DOB, Gender, Degree, Dept, Address) " +
                               "VALUES (@Name, @Email, @Password, @DOB, @Gender, @Degree, @Dept, @Address)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Email", Email);
                    cmd.Parameters.AddWithValue("@Password", pass);
                    cmd.Parameters.AddWithValue("@DOB", dob);
                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@Degree", degree);
                    cmd.Parameters.AddWithValue("@Dept", dept);
                    cmd.Parameters.AddWithValue("@Address", address);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            // Clear all
            lblerrorname.Text = "";
            lblerroremail.Text = "";
            lblerrorpass.Text = "";
            lblerrordob.Text = "";
            lblerrorgender.Text = "";
            lblerrorblood.Text = "";
            lblerrordegree.Text = "";
            lblerrordept.Text = "";
            lblerroraddress.Text = "";

            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtname.Text))
            {
                lblerrorname.Text = "Please enter your name!";
                isValid = false;
            }

           
            string enteredEmail = txtemail.Text.Trim();

            if (string.IsNullOrWhiteSpace(enteredEmail))
            {
                lblerroremail.Text = "Please enter your email!";
                isValid = false;
            }
            else
            {
                try
                {
                    MailAddress email = new MailAddress(enteredEmail);

                    
                    if (email.Address != enteredEmail)
                    {
                        lblerroremail.Text = "Please enter a valid email!";
                        isValid = false;
                    }
                }
                catch
                {
                    lblerroremail.Text = "Please enter a valid email!";
                    isValid = false;
                }
            }

           
            if (string.IsNullOrWhiteSpace(txtpass.Text))
            {
                lblerrorpass.Text = "Please enter password!";
                isValid = false;
            }
            else if (txtpass.Text.Length < 4)
            {
                lblerrorpass.Text = "Password must be at least 6 characters!";
                isValid = false;
            }

            
       
            dob = dtpdob.Value;

           
            if (!rdmale.Checked && !rdfemale.Checked)
            {
                lblerrorgender.Text = "Please select your gender!";
                isValid = false;
            }

           
            if (!cbcse.Checked && !cbeee.Checked && !cbenglish.Checked)
            {
                lblerrordegree.Text = "Please select your degree!";
                isValid = false;
            }

           
            if (string.IsNullOrWhiteSpace(cbdept.Text))
            {
                lblerrordept.Text = "Please select your department!";
                isValid = false;
            }

            // Adress
            if (string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                lblerroraddress.Text = "Please enter your address!";
                isValid = false;
            }

           
            if (!isValid)
            {
                return;
            }
         

            name = txtname.Text.Trim();
            Email = txtemail.Text.Trim();
            pass = txtpass.Text;

            dob = dtpdob.Value;

            
            if (rdmale.Checked)
                gender = "Male";
            else
                gender = "Female";

            
            if (cbcse.Checked)
                degree = "CSE";
            else if (cbeee.Checked)
                degree = "EEE";
            else
                degree = "English";

            dept = cbdept.Text.Trim();
            address = richTextBox1.Text.Trim();

            
            
            InsertIntoTable("Regi");

          

          //clear all

            txtname.Clear();
            txtemail.Clear();
            txtpass.Clear();

            rdmale.Checked = false;
            rdfemale.Checked = false;

            cbcse.Checked = false;
            cbeee.Checked = false;
            cbenglish.Checked = false;

            cbdept.SelectedIndex = -1;
            cbdept.Text = "";

            richTextBox1.Clear();

           
        }
    }
}
